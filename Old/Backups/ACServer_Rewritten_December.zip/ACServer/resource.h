//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ACServer.rc
//
#define IDC_MYICON                      2
#define IDD_ACSERVER_DIALOG             102
#define IDD_ABOUTBOX                    103
#define IDS_APP_TITLE                   103
#define IDD_MAINDLG                     103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDS_HELLO                       106
#define IDI_ACSERVER                    107
#define IDI_SMALL                       108
#define IDC_ACSERVER                    109
#define IDR_ACSERVER                    109
#define IDR_MAINFRAME                   128
#define IDI_NOACT                       130
#define IDI_ACT                         131
#define IDD_OPTIONS                     132
#define IDD_SRVMSG                      134
#define IDR_USERPOPUP                   135
#define IDC_LIST1                       1002
#define IDC_CHARLIST                    1003
#define IDC_CSIP                        1004
#define IDC_WSIP                        1005
#define IDC_STARTLISTEN                 1006
#define IDC_EDIT1                       1008
#define IDC_EDIT2                       1009
#define IDC_EDIT3                       1010
#define ID_FILE_RESETLOG                32771
#define ID_FILE_RESETALLCONNECTIONS     32772
#define ID_FILE_KICKSELECTEDUSER        32773
#define ID_OPTIONS_OPENOPTIONS          32774
#define ID_COMMANDS_SERVERMESSAGE       32775
#define ID_COMMANDS_STARTLISTEN         32776
#define ID_KICK_USER                    32777
#define ID_VIEWINFO                     32778
#define ID_MENUITEM32779                32779
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32780
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
