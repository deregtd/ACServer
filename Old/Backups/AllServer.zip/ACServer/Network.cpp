#include "stdafx.h"

//#include "Network.h"
#include "FixedPackets.h"

cACServer::cACServer()
{
	//Constructor

	WSADATA wsaData;
	WORD wVersionRequested = 0x0202;
	int err;

	err = WSAStartup(wVersionRequested, &wsaData); //for winsock startup

	for (int i=0;i<128;i++)
	{
		ConnUser[i].Connected = false;
		ConnUser[i].State = 0;
		ConnUser[i].Char = 0;
	}

	MaxUsers = 0;
	NumConnected = 0;
	sprintf(ServerName, "Unnamed Server");

//	sprintf(MOTDa, "You have successfully joined a server running an Alpha copy of the AC Server Emulator!\nThere are currently: 0 Clients Connected.\n\n");
	sprintf(MOTDb, "Current Progress on Server:\n* Keeping track of up to 128 players\n* Multiuser Chat is working\n* Players represented by animated, properly-named, properly-moving avatars\n* All emotes working\n* Teleporting\n");

	NumStored = 0;
	for (i=0;i<16384;i++)
	{
		IPStore[i].Enabled = false;
	}

	NeedToDelete = true;

//	CalcNextFreeGUID();
}

cACServer::~cACServer()
{
	//Destructor
	SaveObjects();

	for (int i=0;i<128;i++)
		DisconnectUser(i);

	WSACleanup(); // Always do this at the end of a winsock program
}


void cACServer::StartListen()
{
	LoadObjects();

	srand(time(NULL));

	struct sockaddr_in localAddress;	//IP and port of the local machine
	localAddress.sin_family = AF_INET;
	localAddress.sin_addr.s_addr = inet_addr(LocalIP);
	localAddress.sin_port = htons(ListenPort);

	charSocket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
	
	bind(charSocket, (struct sockaddr *)&localAddress, sizeof(sockaddr_in) );

	sprintf(sayit, "ACServer Server Up!  Listening on port %i...", ListenPort); LogDisp(sayit);

	SendDlgItemMessage(MainWnd, IDC_CHARLIST, LB_RESETCONTENT, 0, 0);
	char tosay[100];
	sprintf(tosay, "User\tIP:Port\t\t\tStatus"); SendDlgItemMessage(MainWnd, IDC_CHARLIST, LB_ADDSTRING, 0, (WPARAM) &tosay[0]);
	for (int i=0;i<128;i++)
	{
		sprintf(tosay, "%i\tN/A\t\t\tNot Connected", i);
		SendDlgItemMessage(MainWnd, IDC_CHARLIST, LB_ADDSTRING, 0, (WPARAM) &tosay[0]);
	}

	//Set up event notification...
	int err = WSAAsyncSelect(charSocket, MainWnd, WM_USER+1, FD_ACCEPT | FD_READ);
}

void cACServer::PingReply(int User)
{
	cServerPacketHeader tph1;
	tph1.m_bTable = 2;
	tph1.m_bTime = ConnUser[User].bTime;
	tph1.m_dwFlags = 0x00000022;
	tph1.m_dwServerID = 0x0000000C;
	tph1.m_wTotalSize = 0x4;
	tph1.m_dwSequence = ConnUser[User].curSeq;

	DWORD tph2 = ConnUser[User].lastInSeq;

	unsigned char outbufping[sizeof(tph1)+sizeof(tph2)];

	DWORD crc1,crc2;
	DWORD *crc;
	crc=(DWORD *)&tph1.m_dwCRC; *crc=0x3291975;
	crc1=GetMagicNumber((BYTE *) &tph2, sizeof(tph2), 0);
	crc2=GetMagicNumber((BYTE *) &tph1, sizeof(tph1), 1);
	*crc=crc1+crc2;

	memcpy(&outbufping[0],&tph1,sizeof(tph1));
	memcpy(&outbufping[sizeof(tph1)],&tph2,sizeof(tph2));
	sendto(charSocket,(char *)outbufping,sizeof(outbufping),NULL,(struct sockaddr *)&ConnUser[User].sockaddy,sizeof(struct sockaddr));
}

void cACServer::LoadAccounts()
{	
	FILE *in = fopen("Password.dat","rb");
	if (!in)
	{
		NumPasses = 0;
		return;
	}
	
	fseek(in, 0, SEEK_END);
	int filelen = ftell(in);
	fseek(in, 0, SEEK_SET);

	NumPasses = (int) (filelen/sizeof(stAccounts));

	fread(ZonePasses, filelen, 1, in);

	for (int i=0;i<NumPasses;i++)
	{
		ZonePasses[i].LoggedIn = (WORD) -1;
	}

	fclose(in);
}

void cACServer::CalcNextFreeGUID()
{
	NextFreeCharGUID = 0x50000000;
	for (int i=0;i<NumPasses;i++)
	{
		for (int j=0;j<5;j++)
		{
			if (ZonePasses[i].Chars[j] >= NextFreeCharGUID)
				NextFreeCharGUID = ZonePasses[i].Chars[j] + 1;
		}
	}
}

void cACServer::SaveAccounts()
{
	FILE *out = fopen("Password.dat","wb");
	if (!out)
	{
		MessageBox(NULL, "Error on Password File Save!  Very bad!!", "Critical Error!", MB_OK);
		return;
	}

	fwrite(ZonePasses, sizeof(stAccounts)*NumPasses, 1, out);

	fclose(out);
}


void cACServer::CheckMessages()
{
	struct fd_set readSet; FD_ZERO(&readSet); FD_SET(charSocket, &readSet);
	struct timeval timeout; timeout.tv_sec = 0; timeout.tv_usec = 0;
	int s = select(NULL, &readSet, NULL, NULL, &timeout); // See if there is data waiting to read on readSet 

	unsigned int amountRead=0;
	int size=sizeof(sockaddr_in);
	cClientPacketHeader tphdr;
	cMessageHeader tph2;
	cServerPacketHeader tph1;

	if(s>0) // If there is no error
	{	  			
		struct sockaddr_in temp;
		amountRead=::recvfrom(charSocket,(char *) TestBuf,1024,NULL,(sockaddr *)&temp,&size);

		memcpy(&tphdr, &TestBuf[0], sizeof(tphdr));

		DWORD crc1,crc2;
		DWORD *crc;

		if (tphdr.m_dwFlags == 0x0000000A)
		{	sprintf(sayit, "* Error Packet..."); LogDisp(sayit); }

		int UserParsing = -1;
		for (int i=0;i<MaxUsers;i++)
		{
			if ((ConnUser[i].Connected) && (ConnUser[i].sockaddy.sin_addr.S_un.S_addr == temp.sin_addr.S_un.S_addr) && (ConnUser[i].sockaddy.sin_port == temp.sin_port))
			{	UserParsing = i; break; }
		}

		if (tphdr.m_dwFlags == 0x00013455)
		{
			//Set Login/Pass
			bool FoundStore = false;
			for (int i=0;i<NumStored;i++)
			{
				if (IPStore[i].Enabled)
				{
					if (IPStore[i].IP.S_un.S_addr == temp.sin_addr.S_un.S_addr)
					{
						FoundStore = true;

						memcpy(IPStore[i].Login, &TestBuf[sizeof(tphdr)],20);
						memcpy(IPStore[i].Pass, &TestBuf[sizeof(tphdr)+20],20);

						IPStore[i].Valid = false;

						bool LoginFound = false;
						//Check for existing Login by that name, or else create new one...
						for (int h=0;h<NumPasses;h++)
						{
							if (strcmp(ZonePasses[h].Login,IPStore[i].Login) == 0)
							{
								//ID Found
								LoginFound = true;
								if (strcmp(ZonePasses[h].Pass,IPStore[i].Pass) == 0)
								{
									//Valid Password
									IPStore[i].Valid = true;

									IPStore[i].ZoneNum = h;

									sprintf(sayit, "User %s logged in.", ZonePasses[h].Login); LogDisp(sayit);
								}
								h = NumStored;
							}
						}
						
						if (!LoginFound)
						{
							memcpy(ZonePasses[NumPasses].Login, IPStore[i].Login, 20);
							memcpy(ZonePasses[NumPasses].Pass, IPStore[i].Pass, 20);
							ZeroMemory(ZonePasses[NumPasses].Chars, sizeof(ZonePasses[NumPasses].Chars));
							ZeroMemory(ZonePasses[NumPasses].Secs2Del, sizeof(ZonePasses[NumPasses].Secs2Del));
							ZeroMemory(ZonePasses[NumPasses].Names, sizeof(ZonePasses[NumPasses].Names));
							sprintf(sayit, "New User %s logged in.", ZonePasses[NumPasses].Login); LogDisp(sayit);
							IPStore[i].ZoneNum = NumPasses;
							IPStore[i].Valid = true;
							ZonePasses[NumPasses].LoggedIn = -1;

							NumPasses++;
							SaveAccounts();
						}

						i = NumStored;
					}
				}
			}

			if (!FoundStore)
			{
				for (i=0;i<16384;i++)
				{
					if (!IPStore[i].Enabled)
					{
						if (i >= NumStored)
							NumStored = i + 1;
						
						memcpy(&IPStore[i].IP, &temp.sin_addr, sizeof(temp.sin_addr));
						IPStore[i].Enabled = true;

						memcpy(IPStore[i].Login, &TestBuf[sizeof(tphdr)],20);
						memcpy(IPStore[i].Pass, &TestBuf[sizeof(tphdr)+20],20);

						IPStore[i].Valid = false;

						bool LoginFound = false;
						//Check for existing Login by that name, or else create new one...
						for (int h=0;h<NumPasses;h++)
						{
							if (strcmp(ZonePasses[h].Login,IPStore[i].Login) == 0)
							{
								//ID Found
								LoginFound = true;
								if (strcmp(ZonePasses[h].Pass,IPStore[i].Pass) == 0)
								{
									//Valid Password
									IPStore[i].Valid = true;

									sprintf(sayit, "User %s logged in.", ZonePasses[h].Login); LogDisp(sayit);

;									IPStore[i].ZoneNum = h;
								}
								h = NumPasses;
							}
						}
						
						if (!LoginFound)
						{
							memcpy(ZonePasses[NumPasses].Login, IPStore[i].Login, 20);
							memcpy(ZonePasses[NumPasses].Pass, IPStore[i].Pass, 20);
							ZeroMemory(ZonePasses[NumPasses].Chars, sizeof(ZonePasses[NumPasses].Chars));
							ZeroMemory(ZonePasses[NumPasses].Secs2Del, sizeof(ZonePasses[NumPasses].Secs2Del));
							ZeroMemory(ZonePasses[NumPasses].Names, sizeof(ZonePasses[NumPasses].Names));
							ZonePasses[NumPasses].LoggedIn = -1;

							sprintf(sayit, "New User %s logged in.", ZonePasses[NumPasses].Login); LogDisp(sayit);

							IPStore[i].Valid = true;
							IPStore[i].ZoneNum = NumPasses;
							LoginFound = true;

							NumPasses++;
							SaveAccounts();
						}

						i = 16384;
					}
				}
			}

			return;
		}

		if (UserParsing == -1)
		{
			for (int i=0;i<128;i++)
			{
				if (!ConnUser[i].Connected)
				{
					UserParsing = i;

					memcpy(&ConnUser[i].sockaddy,&temp,sizeof(sockaddr_in));

					ZeroMemory(ConnUser[i].ZoneName, 20);
					for (int hh=0;hh<NumStored;hh++)
					{
						if ((IPStore[hh].Enabled) && (ConnUser[i].sockaddy.sin_addr.S_un.S_addr == IPStore[hh].IP.S_un.S_addr))
						{
							//Check Password Validation Here
							if ((IPStore[hh].Valid)	&& ((ZonePasses[IPStore[hh].ZoneNum].LoggedIn == (WORD) -1) || (ZonePasses[IPStore[hh].ZoneNum].LoggedIn == i)))	//If valid, set connuser's zoneid!
							{
								memcpy(&ConnUser[i].ZoneName[0], &IPStore[hh].Login[0], 20);

								ZonePasses[IPStore[hh].ZoneNum].LoggedIn = i;

								for (int j=0;j<5;j++)
								{
									ConnUser[i].Chars[j].GUID = ZonePasses[IPStore[hh].ZoneNum].Chars[j];
									memcpy(ConnUser[i].Chars[j].Name, ZonePasses[IPStore[hh].ZoneNum].Names[j], 32);
								}
								
								ConnUser[i].ZoneNum = IPStore[hh].ZoneNum;
							}

							hh = NumStored;
						}
					}
					
					if (strlen(ConnUser[i].ZoneName) == 0)
					{
						//Invalid Login...

						return;
					}					

					ConnUser[i].Connected = true;

					ConnUser[i].State = 1;
					
					ConnUser[i].curSeq = 1;
					ConnUser[UserParsing].EventCount = 0;	//1

					ConnUser[UserParsing].msgID = 1;

					ConnUser[i].bTime = 0;
					ConnUser[i].RecTime = 0;
					ConnUser[i].LastTime = 0;

					ConnUser[UserParsing].move_count = 1;

					ConnUser[UserParsing].SelectedItem = 0;

					ConnUser[UserParsing].PortalCount = 0;
					ConnUser[UserParsing].OverrideCount = 0;
					ConnUser[UserParsing].AnimCount = 0;
					ConnUser[UserParsing].MoveItemCount = 1;
					ConnUser[UserParsing].EquipCount = 0;
					ConnUser[UserParsing].AttackCount = 0;
					ZeroMemory(ConnUser[UserParsing].Count237, sizeof(ConnUser[UserParsing].Count237));
					ZeroMemory(ConnUser[UserParsing].Count244,3);
					
					ConnUser[UserParsing].Connable = true;
					ConnUser[UserParsing].ConnTimer = 0;

					UpdateCharInfo(UserParsing, "Connected...");

					if (i >= MaxUsers)
						MaxUsers = i + 1;

					break;
				}
			}
		}

		if (UserParsing == -1)
			return;

		ConnUser[UserParsing].LastTime = ConnUser[UserParsing].RecTime;
		ConnUser[UserParsing].lastInSeq = tphdr.m_dwSequence;

		if (tphdr.m_dwFlags == 0x00000022)
		{
			if (ConnUser[UserParsing].bTime < tphdr.m_bTime)
				ConnUser[UserParsing].bTime = tphdr.m_bTime;

			PingReply(UserParsing);
			
			return;
		}

		if (ConnUser[UserParsing].State == 1)
		{
			//Character Selection Screen, Just Pings...  Then Entering Game.
			if (tphdr.m_dwFlags == 0x00000802)
			{
				cMessageHeader tpmhdr;
				memcpy(&tpmhdr, &TestBuf[sizeof(cClientPacketHeader)], sizeof(tpmhdr));
				
				DWORD MessageType;	memcpy(&MessageType, &TestBuf[sizeof(cClientPacketHeader) + sizeof(cMessageHeader)], 4);
				
				switch (MessageType)
				{
				case 0xF656:
					{
						//Character Creation!!
						DWORD beefbeef, tpdword;
						BYTE ZoneName[20], shit[0x140], *PackPointer;
						PackPointer = &TestBuf[sizeof(cClientPacketHeader) + sizeof(cMessageHeader) + 4];
						memcpy(&beefbeef, PackPointer, 4);	PackPointer += 4;
						memcpy(ZoneName, PackPointer, 20);	PackPointer += 20;
						memcpy(shit, PackPointer, 0x140);	PackPointer += 0x140;
						
						WORD CharNameLen;
						BYTE CharName[32];
						memcpy(&CharNameLen, PackPointer, 2);			PackPointer += 2;
						memcpy(CharName, PackPointer, CharNameLen);		PackPointer += CharNameLen;

						DWORD CharNum;
						for (int i=0;i<5;i++)
						{
							if (!ConnUser[UserParsing].Chars[i].GUID)
							{
								memcpy(ConnUser[UserParsing].Chars[i].Name, CharName,32);
								CalcNextFreeGUID();
								ConnUser[UserParsing].Chars[i].GUID = NextFreeCharGUID;
								ZonePasses[ConnUser[UserParsing].ZoneNum].Chars[i] = ConnUser[UserParsing].Chars[i].GUID;
								memcpy(ZonePasses[ConnUser[UserParsing].ZoneNum].Names[i], ConnUser[UserParsing].Chars[i].Name,32);
								CharNum = i;
								i = 5;
		
								SaveAccounts();
							}
						}

						//Fill out stCharType and send to WorldServer
						cWorldObject_Char * NewChar = new cWorldObject_Char();
						NewChar->GUID = ConnUser[UserParsing].Chars[CharNum].GUID;
						memcpy(NewChar->Name, CharName, 32);
						
						//Read in shit
						PackPointer = &shit[0];
						DWORD unk1;			memcpy(&unk1, PackPointer, 4);	PackPointer += 4;				//Unknown1
											memcpy(&NewChar->Gender , PackPointer, 4);	PackPointer += 4;	//Guessing its Gender
											memcpy(&NewChar->Race , PackPointer, 4);	PackPointer += 4;	//Race, Aluv/Gharu/Sho 0/1/2
						/*$70 unknown right now*/									PackPointer += 0x70;
											memcpy(&NewChar->InitialStat[0], PackPointer, 6*4);	PackPointer += 6*4;
						/*$10 unknown right now*/									PackPointer += 0x10;
						

						sprintf(sayit, "* %s created a new char, %s with GUID: %08X", ConnUser[UserParsing].ZoneName, NewChar->Name , NewChar->GUID); LogDisp(sayit);

						ZeroMemory(NewChar->SkillInc, sizeof(NewChar->SkillInc));
						ZeroMemory(NewChar->SkillFreeXP, sizeof(NewChar->SkillFreeXP));
						ZeroMemory(NewChar->SkillXP, sizeof(NewChar->SkillXP));
						DWORD tpskill;
						for (i=0; i < 39; i++)
						{
							memcpy(&tpskill, PackPointer, 4);
							PackPointer += 4;
							NewChar->SkillTrain[i+1] = 0;
							if (tpskill)
							{
								NewChar->SkillTrain[i+1] = tpskill;
								if (tpskill == 1)
								{
									NewChar->SkillInc[i+1] = 0;
									NewChar->SkillFreeXP[i+1] = 0;
								}
								if (tpskill == 2)
								{
									NewChar->SkillInc[i+1] = 5;
									NewChar->SkillFreeXP[i+1] = 526;
								}
								if (tpskill == 3)
								{
									NewChar->SkillInc[i+1] = 10;
									NewChar->SkillFreeXP[i+1] = 671;
								}
	
								NewChar->SkillXP[i+1] = 0;
							}
						}
						
						NewChar->Vitae = 0;

						NewChar->Level = 1;

						//Eventually decode starting place... For now teth works. :)
						NewChar->Loc.landblock = 0x25810034;
						NewChar->Loc.x = 156.1f;
						NewChar->Loc.y = 81.9f;
						NewChar->Loc.z = 220.0f;

						tpdword = 0x3F579630; memcpy(&NewChar->Loc.a, &tpdword, 4);
						NewChar->Loc.b = 0x00000000;
						NewChar->Loc.c = 0x00000000;
						NewChar->Loc.w = 90.1f;	//Heading

						memcpy(&NewChar->LSTie, &NewChar->Loc, sizeof(NewChar->Loc));

						NewChar->CurrentSecondaryStat[0] = NewChar->InitialStat[1]/2;
						NewChar->CurrentSecondaryStat[1] = NewChar->InitialStat[1];
						NewChar->CurrentSecondaryStat[2] = NewChar->InitialStat[5];

						ZeroMemory(NewChar->XPIntoSecondaryStat, sizeof(NewChar->XPIntoSecondaryStat));
						ZeroMemory(NewChar->XPIntoStat, sizeof(NewChar->XPIntoStat));
						ZeroMemory(NewChar->SecondaryStatInc, sizeof(NewChar->SecondaryStatInc));

						memcpy(NewChar->CurrentStat, NewChar->InitialStat, 6*4);

						ZeroMemory(NewChar->MainPack, sizeof(NewChar->MainPack));
						ZeroMemory(NewChar->SidePacks, sizeof(NewChar->SidePacks));
						ZeroMemory(NewChar->Equipped, sizeof(NewChar->Equipped));
						NewChar->Model = 1;
						NewChar->Monarch = 0;
						NewChar->NumLogins = 1;
						NewChar->Options = 0x01E8E543;
						NewChar->Patron = 0;
						NewChar->SkillCredits = 0;
						ZeroMemory(NewChar->SpellsLearned, sizeof(NewChar->SpellsLearned));
						NewChar->TotalXP = 0;
						NewChar->UnassignedXP = 0;
						NewChar->Vitae = 0;
						NewChar->Class = 0;
						ZeroMemory(NewChar->Vassal, sizeof(NewChar->Vassal));
						ZeroMemory(NewChar->ShortCut, sizeof(NewChar->ShortCut));
						ZeroMemory(NewChar->SpellsLearned, sizeof(NewChar->SpellsLearned));
						ZeroMemory(NewChar->SpellBar, sizeof(NewChar->SpellBar));

						FILE *out = fopen("CharList.dat","a+b");

						fseek(out, 0, SEEK_END);
						
						BYTE TPlog[0x2000]; int charsize = NewChar->Serialize(TPlog);
						fwrite(&NewChar->GUID, 4, 1, out);
						fwrite(NewChar->Name, 32, 1, out);
						fwrite(&NewChar->Loc, sizeof(Location_t), 1, out);
						fwrite(TPlog, charsize, 1, out);

						fclose(out);

						sprintf(sayit, "New char created: %s with GUID %08X", NewChar->Name, NewChar->GUID); LogDisp(sayit);

						//Create Char Respond Packet...
						BYTE CreateChar[0x100];
						
						
						PackPointer = &CreateChar[0];

						tpdword = 0x0000F643;		memcpy(PackPointer, &tpdword, 4);	PackPointer += 4;
						tpdword = 0x00000001;		memcpy(PackPointer, &tpdword, 4);	PackPointer += 4;	//Success
						tpdword = ConnUser[UserParsing].Chars[CharNum].GUID;	memcpy(PackPointer, &tpdword, 4);	PackPointer += 4;
						int outlen; GenString(ConnUser[UserParsing].Chars[CharNum].Name, &outlen, PackPointer); PackPointer += outlen;
						tpdword = 0x00000000;		memcpy(PackPointer, &tpdword, 4);	PackPointer += 4;

						tph2.m_wUnknown1 = 0x0004;
						tph2.m_dwSequence = ConnUser[UserParsing].msgID;
						DWORD PackLen = (DWORD) ((DWORD) PackPointer - (DWORD) CreateChar);

						Send802(&tph2, CreateChar, PackLen, UserParsing);

						//Resend Char List!
						SendCharList(UserParsing);
					}
					break;
				case 0xF7C8:
					{
						//Entering Game
						UpdateCharInfo(UserParsing, "Got Enter Game Packet...");

						//Now to return a fun 802 packet... whee...
//						tph2.m_dwSequence = 0x002CC00F;
						tph2.m_wUnknown1 = 0x0004;

						DWORD tph3 = 0x0000F7C7;

						Send802(&tph2, (BYTE *) &tph3, sizeof(tph3), UserParsing);

						ConnUser[UserParsing].State = 2;
					}
					break;
				case 0xF7D9:
					//Restoring Character
					{
						DWORD GUIDtoRestore; DWORD Ones[2];
						memcpy(&GUIDtoRestore, &TestBuf[sizeof(tphdr)+sizeof(tpmhdr)+4],4);
						memcpy(&Ones[0], &TestBuf[sizeof(tphdr)+sizeof(tpmhdr)+8],4);
						memcpy(&Ones[1], &TestBuf[sizeof(tphdr)+sizeof(tpmhdr)+12],4);

						int CharRestoring = 0;
						for (int i=0;i<5;i++)
						{
							if ((ConnUser[UserParsing].Chars[i].GUID & 0x7FFFFFFF) == GUIDtoRestore)
							{
								ConnUser[UserParsing].Chars[i].GUID &= 0x7FFFFFFF;
								
								ZonePasses[ConnUser[UserParsing].ZoneNum].Chars[i] = ConnUser[UserParsing].Chars[i].GUID;
								
								SaveAccounts();

								CharRestoring = i;
								i = 5;
							}
						}

						BYTE CreateChar[0x100], *PackPointer = &CreateChar[0];
						DWORD tpdword;

						tpdword = 0x0000F643;		memcpy(PackPointer, &tpdword, 4);	PackPointer += 4;
						tpdword = 0x00000001;		memcpy(PackPointer, &tpdword, 4);	PackPointer += 4;
						tpdword = GUIDtoRestore;	memcpy(PackPointer, &tpdword, 4);	PackPointer += 4;

						tpdword = ConnUser[UserParsing].Chars[i].GUID & 0x7FFFFFFF;
							memcpy(PackPointer,&tpdword,4); PackPointer += 4;	//GUID

						BYTE NameLen;
						NameLen = strlen(ConnUser[UserParsing].Chars[CharRestoring].Name) + 1;
							memcpy(PackPointer,&NameLen,sizeof(NameLen)); PackPointer += sizeof(NameLen);	//NameLen

						*PackPointer = 0; PackPointer++;												//0
						NameLen--; memcpy(PackPointer,&ConnUser[UserParsing].Chars[CharRestoring].Name,NameLen); PackPointer += NameLen;	//Name
						*PackPointer = 0; PackPointer++;												//0
						
						int Tpl = ((PackPointer-&CreateChar[0])%4); if (Tpl) Tpl=4-Tpl;			//Padding
						for (int ii=0;ii<Tpl;ii++) {	*PackPointer = 0; PackPointer++; }		//"
						
						tpdword = 0x00000000;		memcpy(PackPointer, &tpdword, 4);	PackPointer += 4;
						tph2.m_wUnknown1 = 0x0004;
						Send802(&tph2, &CreateChar[0], (int) (PackPointer - &CreateChar[0]), UserParsing);

						//Resend Char List!
						SendCharList(UserParsing);
					}
					break;
				case 0xF655:
					//Deleting Character
					{
						DWORD beefbeef; char ZoneName[20]; DWORD LastWord[2];
						memcpy(&beefbeef, &TestBuf[sizeof(tphdr)+sizeof(tpmhdr)+4],4);
						memcpy(&ZoneName, &TestBuf[sizeof(tphdr)+sizeof(tpmhdr)+8],20);
						memcpy(&LastWord[0], &TestBuf[sizeof(tphdr)+sizeof(tpmhdr)+28],4);
						memcpy(&LastWord[1], &TestBuf[sizeof(tphdr)+sizeof(tpmhdr)+32],4);

						//LastWord[0] seems to be 01f7 all the time
						//LastWord[1] is the index of the char deleted, in order of chars sent, i think...
						
						ConnUser[UserParsing].Chars[LastWord[1]].GUID |= 0x80000000;	//To be deleted
						ZonePasses[ConnUser[UserParsing].ZoneNum].Chars[LastWord[1]] = ConnUser[UserParsing].Chars[LastWord[1]].GUID;
						ZonePasses[ConnUser[UserParsing].ZoneNum].Secs2Del[LastWord[1]] = 300;	//5 Minutes
						SaveAccounts();
						
						NeedToDelete = true;
						
						//F7B0/F655
/*						DWORD F7B0F655[] = {
							0x0000F7B0,
							ConnUser[UserParsing].charGUID,
							ConnUser[UserParsing].EventCount,
							0x0000F655,
							LastWord[1]	//?...
						};
						tph2.m_wUnknown1 = 6;
						tph2.m_dwSequence = ConnUser[UserParsing].msgID;
						ConnUser[UserParsing].EventCount++;
						Send802(&tph2, (BYTE *) &F7B0F655[0], sizeof(F7B0F655), UserParsing);*/

						//Resend Char List!
						SendCharList(UserParsing);
					}
					break;
				default:
					break;
				}
			} else if ((tphdr.m_dwFlags == 0x00008002) && (ConnUser[UserParsing].Connable)) {
//				sprintf(sayit, "-=*=- Connection Packet Detected... Logging In... -=*=-"); LogDisp(sayit);

				UpdateCharInfo(UserParsing, "Sending Initial Info...");

				
				ConnUser[UserParsing].Connable = false;
				ConnUser[UserParsing].ConnTimer = 5;

				int amountWritten;

				amountWritten=::sendto(charSocket,(char *)PacketOne,sizeof(PacketOne),NULL,(struct sockaddr *)&temp,sizeof(struct sockaddr));
				amountWritten=::sendto(charSocket,(char *)PacketOne,sizeof(PacketOne),NULL,(struct sockaddr *)&temp,sizeof(struct sockaddr));
				amountWritten=::sendto(charSocket,(char *)PacketOne,sizeof(PacketOne),NULL,(struct sockaddr *)&temp,sizeof(struct sockaddr));
				amountWritten=::sendto(charSocket,(char *)PacketOne,sizeof(PacketOne),NULL,(struct sockaddr *)&temp,sizeof(struct sockaddr));
				amountWritten=::sendto(charSocket,(char *)PacketOne,sizeof(PacketOne),NULL,(struct sockaddr *)&temp,sizeof(struct sockaddr));

				amountWritten=::sendto(charSocket,(char *)PacketTwo,sizeof(PacketTwo),NULL,(struct sockaddr *)&temp,sizeof(struct sockaddr));
				amountWritten=::sendto(charSocket,(char *)PacketThree,sizeof(PacketThree),NULL,(struct sockaddr *)&temp,sizeof(struct sockaddr));
				amountWritten=::sendto(charSocket,(char *)PacketFour,sizeof(PacketFour),NULL,(struct sockaddr *)&temp,sizeof(struct sockaddr));
				amountWritten=::sendto(charSocket,(char *)PacketFive,sizeof(PacketFive),NULL,(struct sockaddr *)&temp,sizeof(struct sockaddr));
				amountWritten=::sendto(charSocket,(char *)PacketSix,sizeof(PacketSix),NULL,(struct sockaddr *)&temp,sizeof(struct sockaddr));
				amountWritten=::sendto(charSocket,(char *)PacketSeven,sizeof(PacketSeven),NULL,(struct sockaddr *)&temp,sizeof(struct sockaddr));
				amountWritten=::sendto(charSocket,(char *)PacketEight,sizeof(PacketEight),NULL,(struct sockaddr *)&temp,sizeof(struct sockaddr));
				amountWritten=::sendto(charSocket,(char *)PacketNine,sizeof(PacketNine),NULL,(struct sockaddr *)&temp,sizeof(struct sockaddr));
				amountWritten=::sendto(charSocket,(char *)PacketTen,sizeof(PacketTen),NULL,(struct sockaddr *)&temp,sizeof(struct sockaddr));
				amountWritten=::sendto(charSocket,(char *)PacketEleven,sizeof(PacketEleven),NULL,(struct sockaddr *)&temp,sizeof(struct sockaddr));
				amountWritten=::sendto(charSocket,(char *)PacketTwelve,sizeof(PacketTwelve),NULL,(struct sockaddr *)&temp,sizeof(struct sockaddr));
				amountWritten=::sendto(charSocket,(char *)Packet13,sizeof(Packet13),NULL,(struct sockaddr *)&temp,sizeof(struct sockaddr));

//Packet 14
				BYTE packbuf[0x200];
				cMessageHeader tph2;
				unsigned char *PackPointer;
				
				tph2.m_dwSequence = 0x000D648A;
				tph2.m_wUnknown1 = 0x0007;

				PackPointer = &packbuf[0x0];

				unsigned char MSG_F7B8[28] = {
					0xB8, 0xF7, 0x00, 0x00, 0xA3, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x33, 0x01, 0x00, 0x00,
					0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
				};
				memcpy(PackPointer,&MSG_F7B8,sizeof(MSG_F7B8));		PackPointer += sizeof(MSG_F7B8);	//The Fixed Message

				Send802(&tph2, &packbuf[0], (int) (PackPointer - &packbuf[0]), UserParsing);
				Send802(&tph2, &packbuf[0], (int) (PackPointer - &packbuf[0]), UserParsing);

//Char List 802
				SendCharList(UserParsing);

				UpdateCharInfo(UserParsing, "Selecting Character");

				return;
			} else if (tphdr.m_dwFlags == 0x00000022) {
				//Ping...
			} else if (tphdr.m_dwFlags == 0x00008002) {
				//Proxy Wakeup
			} else if (tphdr.m_dwFlags == 0x00000002) {
				//Meh
			} else if (tphdr.m_dwFlags == 0x00000202) {
				//CD login-packet
			} else if (tphdr.m_dwFlags == 0x00000102) {
				//Dunno
			} else if (tphdr.m_dwFlags == 0x00001002) {
				ConnUser[UserParsing].bTime++;
				//Btime raised...
			} else if (tphdr.m_dwFlags == 0x00000042) {
				//Dunno...
			} else if (tphdr.m_dwFlags == 0x0000000a) {
				//Error packet...
			} else {
				int aa=4;
				//Dunno...
			}
		} else if (ConnUser[UserParsing].State == 2) {
			//Waiting for Login 802-Ack...
			if (tphdr.m_dwFlags == 0x00000802) {
				cMessageHeader tpmhdr;
				memcpy(&tpmhdr, &TestBuf[sizeof(cClientPacketHeader)], sizeof(tpmhdr));
			
				UpdateCharInfo(UserParsing, "Got 802, Sending 400002...");

//				sprintf(sayit, "-*- Recieved Proxy-SockAddr 802 packet, Replying with 400002 Packet..."); LogDisp(sayit);

				memcpy(&ConnUser[UserParsing].charGUID, &TestBuf[4+sizeof(cMessageHeader)+sizeof(cClientPacketHeader)], 4);
				//memcpy(&ConnUser[UserParsing].ZoneName[0], &TestBuf[0x0C+sizeof(cMessageHeader)+sizeof(cClientPacketHeader)], 20);
				
				cServerPacketHeader sockheader;
				sockheader.m_bTable = 2;
				sockheader.m_bTime = ConnUser[UserParsing].bTime;
				sockheader.m_dwFlags = 0x00400002;
				ConnUser[UserParsing].curSeq++;
				sockheader.m_dwSequence = ConnUser[UserParsing].curSeq; //0x00000000;
				sockheader.m_dwServerID = 0x0000000C;
				sockheader.m_wTotalSize = 0x0010;
				
				sockaddr_in sockheader2;
				ZeroMemory(&sockheader2,sizeof(sockheader2));
				sockheader2.sin_family = 0x0002;
				sockheader2.sin_port = htons ((u_short)ListenPort);
				sockheader2.sin_addr.S_un.S_addr = inet_addr(LocalIP);

				sprintf(sayit, "-=*=- Logging into GUID: %08X, Zone Name: %s", ConnUser[UserParsing].charGUID, ConnUser[UserParsing].ZoneName); LogDisp(sayit);

				unsigned char treply[0x24];
				memcpy(&treply[sizeof(sockheader)],&sockheader2,sizeof(sockheader2));

				DWORD crc1,crc2, *crc;
				crc=(DWORD *)&sockheader.m_dwCRC; *crc=0x3291975;
				crc1=GetMagicNumber((BYTE *) &sockheader2, sizeof(sockheader2), 0);
				crc2=GetMagicNumber((BYTE *) &sockheader, sizeof(sockheader), 1);
				*crc=crc1+crc2;

				memcpy(&treply[0],&sockheader,sizeof(sockheader));
				sendto(charSocket,(char *)treply,sizeof(treply),NULL,(struct sockaddr *)&ConnUser[UserParsing].sockaddy,sizeof(struct sockaddr));
				
				ConnUser[UserParsing].State = 3;
			} else if (tphdr.m_dwFlags == 0x00001002) {
				ConnUser[UserParsing].bTime++;
				//Btime raised...
			} else {
				//Dunno...
			}
		} else if (ConnUser[UserParsing].State == 3) {
			//Referring to WorldServer
			if (tphdr.m_dwFlags == 0x00400002) {
				//Update to WorldServer...
				UpdateCharInfo(UserParsing, "Updating to WorldServer");

				ConnUser[UserParsing].State = 4;

				DWORD GUIDtoLoad = ConnUser[UserParsing].charGUID;

				//Load character...
				FILE *charread = fopen("CharList.dat","rb");

				if (!charread)
				{
					//doh
					sprintf(sayit, "Couldn't find Character File... Bad... Disconnecting User..."); LogDisp(sayit);
					
					return;			//Bad...
				}

				fseek(charread, 0, SEEK_END);
				int numchars = ftell(charread)/(SIZEOFCHAR+68);
				fseek(charread, 0, SEEK_SET);

				DWORD GUIDtemp; bool CharFound = false;
				for (int j=0;j<numchars;j++)
				{
					fseek(charread, j*(SIZEOFCHAR+68), SEEK_SET);
					fread(&GUIDtemp, 4, 1, charread);
					if (GUIDtemp == GUIDtoLoad)
					{
						fseek(charread, j*(SIZEOFCHAR+68), SEEK_SET);
						cWorldObject_Char *tpchar = new cWorldObject_Char();
						ObjectList[GUIDtemp] = tpchar;
						ConnUser[UserParsing].Char = tpchar;

						fread(&tpchar->GUID, 4, 1, charread);
						fread(tpchar->Name, 32, 1, charread);
						fread(&tpchar->Loc, sizeof(Location_t), 1, charread);
						BYTE tpl[5000];
						fread(tpl, SIZEOFCHAR, 1, charread);
						tpchar->LoadFrom(tpl);
						
						j = numchars;
						CharFound = true;
					}
				}

				fclose(charread);

				if (!CharFound)
				{
					sprintf(sayit, "Couldn't find Character's Entry... Bad... Disconnecting User..."); LogDisp(sayit);
					
					return;			//Bad...
				}

				LBObjects[ConnUser[UserParsing].Char->Loc.landblock >> 16][ConnUser[UserParsing].Char->GUID] = (cWorldObject *) ConnUser[UserParsing].Char;

				//Load Objects out of store...
				for (j=0;j<25;j++) {
					if (ConnUser[UserParsing].Char->Equipped[j]) {
						ConnUser[UserParsing].EquippedPtr[j] = ObjectList[ConnUser[UserParsing].Char->Equipped[j]];
						ConnUser[UserParsing].ObjectCache[ConnUser[UserParsing].Char->Equipped[j]] = ConnUser[UserParsing].EquippedPtr[j];
					} else j = 25;
				}
				for (j=0;j<7;j++) {
					if (ConnUser[UserParsing].Char->SidePacks[j]) {
						ConnUser[UserParsing].SidePacksPtr[j] = ObjectList[ConnUser[UserParsing].Char->SidePacks[j]];
						ConnUser[UserParsing].ObjectCache[ConnUser[UserParsing].Char->SidePacks[j]] = ConnUser[UserParsing].SidePacksPtr[j];
					} else j = 7;
				}
				for (j=0;j<102;j++) {
					if (ConnUser[UserParsing].Char->MainPack[j]) {
						ConnUser[UserParsing].MainPackPtr[j] = ObjectList[ConnUser[UserParsing].Char->MainPack[j]];
						ConnUser[UserParsing].ObjectCache[ConnUser[UserParsing].Char->MainPack[j]] = ConnUser[UserParsing].MainPackPtr[j];
					} else j = 102;
				}

				ConnUser[UserParsing].Char->Owner = UserParsing;

				//Hax0r...?
				ConnUser[UserParsing].Char->NumLogins = 3; //++;

				/*ConnUser[UserParsing].curSeq++;*/ tph1.m_dwSequence = ConnUser[UserParsing].curSeq;
				tph1.m_dwFlags = 0x00000402;
				tph1.m_dwServerID = 0x0000000C;
				tph1.m_wTotalSize = 0x48;
				tph1.m_bTime = ConnUser[UserParsing].bTime;
				tph1.m_bTable = 2;

				unsigned char FirstPacketData[] = {
					0x35, 0x00, 0x00, 0x00, 0x00, 0x20, 0x00, 0x20, 0x3C, 0x00, 0x00, 0x00,
					0x88, 0x77, 0x66, 0x33, 0x08, 0x00, 0x00, 0x00, 0xFB, 0x63, 0xC5, 0x08, 0x16, 0xC7, 0x80, 0x31,
					0xFF, 0x43, 0xE5, 0xFE, 0x8A, 0xF3, 0xE3, 0x69, 0x23, 0xCF, 0xF8, 0x82, 0xB9, 0xC4, 0x59, 0x80,
					0x99, 0x30, 0xB6, 0x08, 0xE5, 0xC2, 0x80, 0xDD, 0xBB, 0xAD, 0xCD, 0xAD, 0x03, 0x00, 0x00, 0x00,
					0x26, 0x24, 0x64, 0x38, 0x05, 0x73, 0xA1, 0xAE, 0x85, 0x48, 0xDF, 0xBB
				};			

				crc=(DWORD *)&tph1.m_dwCRC; *crc=0x3291975;
				crc1=GetMagicNumber((BYTE *) &FirstPacketData[0], sizeof(FirstPacketData), 0);
				crc2=GetMagicNumber((BYTE *) &tph1, sizeof(tph1), 1);
				*crc=crc1+crc2;

				unsigned char outbuf1[sizeof(tph1)+sizeof(FirstPacketData)];
				memcpy(&outbuf1[0],&tph1,sizeof(tph1));
				memcpy(&outbuf1[sizeof(tph1)],&FirstPacketData,sizeof(FirstPacketData));
				
				sendto(charSocket,(char *)outbuf1,sizeof(outbuf1),NULL,(struct sockaddr *)&ConnUser[UserParsing].sockaddy,sizeof(struct sockaddr));

				sprintf(sayit, "* Requested Login, Loaded char %08X...", ConnUser[UserParsing].Char->GUID);	LogDisp(sayit);
				
				UpdateCharInfo(UserParsing, "Connected! Sending 402...");

				if (i >= MaxUsers)
					MaxUsers = i+1;
			} else {
				//Dunno, wtf...? =]
				if (tphdr.m_dwFlags == 0x00000802) {
					cMessageHeader tpmhdr;
					memcpy(&tpmhdr, &TestBuf[sizeof(cClientPacketHeader)], sizeof(tpmhdr));

					char *tps2;
					sprintf(sayit, "* 802 Pack: Seq:%08X Srv:%08X CRC:%08X Size:%04X Tm:%02X Table:%02X", tphdr.m_dwSequence, tphdr.m_dwServerID, tphdr.m_dwCRC, tphdr.m_wTotalSize, tphdr.m_bTime, tphdr.m_bTable); LogDisp(sayit);
					
					char * tps3 = new char[1 + (amountRead - (sizeof(cMessageHeader)+sizeof(cClientPacketHeader)))*5];
					ZeroMemory(tps3,1 + (amountRead - (sizeof(cMessageHeader)+sizeof(cClientPacketHeader)))*5);
					tps2 = tps3;
					for (unsigned int tpl=0; tpl < (amountRead - (sizeof(cMessageHeader)+sizeof(cClientPacketHeader))); tpl++)
					{
						sprintf(tps2, "0x%02X ", TestBuf[sizeof(cMessageHeader)+sizeof(cClientPacketHeader)+tpl]);
						tps2+=5;
					}
					sprintf(sayit, "\\>Seq:%08X OID:%08X FragCnt:%04X FragLen:%04X FragIdx:%04X Unknown:%04X", tpmhdr.m_dwSequence, tpmhdr.m_dwObjectID, tpmhdr.m_wFragmentCount, tpmhdr.m_wFragmentLength, tpmhdr.m_wFragmentIndex, tpmhdr.m_wUnknown1); LogDisp(sayit);
					sprintf(sayit, "\\>Data: %s", tps3); LogDisp(sayit);
					delete [] tps3;
				} else {
					char * tps = new char[1 + (amountRead-20)*5], *tps2 = tps;
					for (unsigned int tpl=0; tpl < (amountRead-20) ;tpl++)
					{
						sprintf(tps2, "0x%02X ", TestBuf[tpl+20]);
						tps2+=5;
					}
					sprintf(sayit, "In:Seq:%08X Flg:%08X Srv:%08X CRC:%08X Size:%04X Tm:%02X Table:%02X* Data: %s", tphdr.m_dwSequence, tphdr.m_dwFlags, tphdr.m_dwServerID, tphdr.m_dwCRC, tphdr.m_wTotalSize, tphdr.m_bTime, tphdr.m_bTable, tps); LogDisp(sayit);
					delete [] tps;
				}
			}
		} else if (ConnUser[UserParsing].State == 4) {
			if (tphdr.m_dwFlags == 0x00000402) {
				UpdateCharInfo(UserParsing, "Got 402 Ack, Sending 2002...");

				//Second Packet
				/*ConnUser[UserParsing].curSeq++; */tph1.m_dwSequence = ConnUser[UserParsing].curSeq;// ConnUser[UserParsing].curSeq++;
				tph1.m_dwFlags = 0x00002002;
				tph1.m_dwServerID = 0x0000000C;
				tph1.m_wTotalSize = 0x08;
				tph1.m_bTime = ConnUser[UserParsing].bTime;
				tph1.m_bTable = 2;
				
				unsigned char SecondPacketData[] = {
					0x9A, 0xCA, 0x41, 0xBC, 0x8E, 0x41, 0x61, 0x41
				};

				DWORD crc1,crc2, *crc;
				crc=(DWORD *)&tph1.m_dwCRC; *crc=0x3291975;
				crc1=GetMagicNumber((BYTE *) &SecondPacketData[0], sizeof(SecondPacketData), 0);
				crc2=GetMagicNumber((BYTE *) &tph1, sizeof(tph1), 1);
				*crc=crc1+crc2;

				unsigned char outbuf2[sizeof(tph1)+sizeof(SecondPacketData)];
				memcpy(&outbuf2[0],&tph1,sizeof(tph1));
				memcpy(&outbuf2[sizeof(tph1)],&SecondPacketData,sizeof(SecondPacketData));
				sendto(charSocket,(char *)outbuf2,sizeof(outbuf2),NULL,(struct sockaddr *)&ConnUser[UserParsing].sockaddy,sizeof(struct sockaddr));

				ConnUser[UserParsing].State = 5;
			}
		} else if (ConnUser[UserParsing].State == 5) {
			if (tphdr.m_dwFlags == 0x00002002) {
//					sprintf(sayit, "-*- 2002 Ack Recieved!  Sending Large 802 Char Data Packet...  Don Hardhats..."); LogDisp(sayit);
				UpdateCharInfo(UserParsing, "Got 2002 Ack!  Sending Main Login Info...");

				ServerMessage(UserParsing, "Welcome to KillaServ v-9.432", COLOR_BLUE);
				ServerMessage(UserParsing, "* Type !help for a Features List!", COLOR_BLUE);

				sprintf(sayit, "Player %s Joined!", ConnUser[UserParsing].Char->Name);
				ServerMessage(GLOBAL_MESSAGE, sayit, COLOR_GREEN);
				
				//Try to login...
				
				tph2.m_dwSequence = 0x008A9900;
				tph2.m_wUnknown1 = 0x0004;

				BYTE CharData[0x2000];
				int packlen = Generate_F7B0_13(CharData, UserParsing);
//				{
//				FILE *meh = fopen("c:\\a.txt", "wb");
//				fwrite(CharData, packlen, 1, meh);
//				fclose(meh);
//				}
				Send802(&tph2, CharData, packlen, UserParsing);

				tph2.m_wUnknown1 = 0x0003;
				
				//SetPackContents eventually here for any of the 7 packs..

				//Create him on other ppl..
				tph2.m_wUnknown1 = 0x0003;
				
				BYTE CreatePlayer[0x2000];
				packlen = ConnUser[UserParsing].Char->GenerateCreatePacket(CreatePlayer);

				for (int iii=0;iii<MaxUsers;iii++)
				{
					if ((ConnUser[iii].Connected) && ((ConnUser[iii].State == 6) || (iii == UserParsing)))
						Send802(&tph2, &CreatePlayer[0], packlen, iii);
				}

				memcpy(&LOGIN_CHAR[4],&ConnUser[UserParsing].Char->GUID,4);
				Send802(&tph2, &LOGIN_CHAR[0], sizeof(LOGIN_CHAR), UserParsing);

				WORD BaseBlock = ConnUser[UserParsing].Char->Loc.landblock >> 16;
				SendLandblock(UserParsing, BaseBlock);
				SendLandblock(UserParsing, BaseBlock-1);
				SendLandblock(UserParsing, BaseBlock+1);
				SendLandblock(UserParsing, BaseBlock-256);
				SendLandblock(UserParsing, BaseBlock+256);
				SendLandblock(UserParsing, BaseBlock-1-256);
				SendLandblock(UserParsing, BaseBlock+1-256256);
				SendLandblock(UserParsing, BaseBlock-1+256);
				SendLandblock(UserParsing, BaseBlock+1+256);

				tph2.m_dwSequence = 1;
				
				//Exit Portal Mode
				memcpy(&MSG_00000002[4],&ConnUser[UserParsing].Char->GUID,4);
				Send802(&tph2, &MSG_00000002[0], sizeof(MSG_00000002), UserParsing);

				ConnUser[UserParsing].State = 6;
			}			
		} else if (ConnUser[UserParsing].State == 6) {
			WorldServerParse(UserParsing, TestBuf, amountRead, &tphdr);
		} else {
			if (tphdr.m_dwFlags == 0x00000802) {
				cMessageHeader tpmhdr;
				memcpy(&tpmhdr, &TestBuf[sizeof(cClientPacketHeader)], sizeof(tpmhdr));

				char *tps2;
				sprintf(sayit, "* 802 Pack: Seq:%08X Srv:%08X CRC:%08X Size:%04X Tm:%02X Table:%02X", tphdr.m_dwSequence, tphdr.m_dwServerID, tphdr.m_dwCRC, tphdr.m_wTotalSize, tphdr.m_bTime, tphdr.m_bTable); LogDisp(sayit);
				
				char * tps3 = new char[1 + (amountRead - (sizeof(cMessageHeader)+sizeof(cClientPacketHeader)))*5];
				ZeroMemory(tps3,1 + (amountRead - (sizeof(cMessageHeader)+sizeof(cClientPacketHeader)))*5);
				tps2 = tps3;
				for (unsigned int tpl=0; tpl < (amountRead - (sizeof(cMessageHeader)+sizeof(cClientPacketHeader))); tpl++)
				{
					sprintf(tps2, "0x%02X ", TestBuf[sizeof(cMessageHeader)+sizeof(cClientPacketHeader)+tpl]);
					tps2+=5;
				}
				sprintf(sayit, "\\>Seq:%08X OID:%08X FragCnt:%04X FragLen:%04X FragIdx:%04X Unknown:%04X", tpmhdr.m_dwSequence, tpmhdr.m_dwObjectID, tpmhdr.m_wFragmentCount, tpmhdr.m_wFragmentLength, tpmhdr.m_wFragmentIndex, tpmhdr.m_wUnknown1); LogDisp(sayit);
				sprintf(sayit, "\\>Data: %s", tps3); LogDisp(sayit);
				delete [] tps3;
			} else {
				char * tps = new char[1 + (amountRead-20)*5], *tps2 = tps;
				for (unsigned int tpl=0; tpl < (amountRead-20) ;tpl++)
				{
					sprintf(tps2, "0x%02X ", TestBuf[tpl+20]);
					tps2+=5;
				}
				sprintf(sayit, "In:Seq:%08X Flg:%08X Srv:%08X CRC:%08X Size:%04X Tm:%02X Table:%02X* Data: %s", tphdr.m_dwSequence, tphdr.m_dwFlags, tphdr.m_dwServerID, tphdr.m_dwCRC, tphdr.m_wTotalSize, tphdr.m_bTime, tphdr.m_bTable, tps); LogDisp(sayit);
				delete [] tps;
			}
		}
	}
}

void cACServer::LogDisp(char *toDisp)
{
	int numtodisp = 1 + (int) (strlen(toDisp)/90);
	char tosay[91];
	tosay[90] = 0;
	int lognum;
	for (int i=0;i<numtodisp;i++)
	{
		memcpy(&tosay[0],toDisp+(i*90),90);
		lognum = SendDlgItemMessage(MainWnd, IDC_LIST1, LB_ADDSTRING/*LB_INSERTSTRING*/, 0, (LPARAM) tosay);
	}

	SendDlgItemMessage(MainWnd, IDC_LIST1, LB_SETTOPINDEX, lognum-16, 0);
}

DWORD cACServer::GetMagicNumber(BYTE *buf, UINT cb, BOOL bIncludeSize)
{
	DWORD dwCS = 0;
	UINT i;
	if ( bIncludeSize )
	{
		dwCS += cb<<16;
	}
	// sum up the DWORDs:
	for (  i = 0; i<(cb>>2); i++ )
	{
		dwCS += ((DWORD *)buf)[i];
	}
	// now any remaining bytes are summed in reverse endian
	int shift=3;
	for ( i=(i<<2); i<cb; i++ )
	{
		dwCS += buf[i]<<(shift*8);
		shift--;
	}
	return dwCS;
}

void cACServer::IncTimes()
{
	for (int i=0;i<MaxUsers;i++)
	{
		if (ConnUser[i].Connected)
		{
			if (!ConnUser[i].Connable)
			{
				ConnUser[i].ConnTimer--;
				if (!ConnUser[i].ConnTimer)
					ConnUser[i].Connable = true;
			}

//			ConnUser[i].bTime++;
//			if (ConnUser[i].bTime > 80)
//				ConnUser[i].bTime = 0;

			ConnUser[i].RecTime++;
			if ((ConnUser[i].RecTime - ConnUser[i].LastTime) > 30)		//If 30 seconds...
			{
				DisconnectUser(i);
//				sprintf(sayit, "* User %i timed out, disconnecting...", i);  LogDisp(sayit);
			}
		}
	}

	if (NeedToDelete)
	{
		NeedToDelete = false;
		for (i=0;i<NumPasses;i++)
		{
			for (int j=0;j<5;j++)
			{
				if (ZonePasses[i].Secs2Del[j])
				{
					ZonePasses[i].Secs2Del[j]--;
					if (!ZonePasses[i].Secs2Del[j])
					{
						ZonePasses[i].Chars[j] = 0;
						ZeroMemory(ZonePasses[i].Names[j], 32);
						if (ZonePasses[i].LoggedIn != -1)
						{
							ConnUser[ZonePasses[i].LoggedIn].Chars[j].GUID = 0;

							ZeroMemory(ConnUser[ZonePasses[i].LoggedIn].Chars[j].Name, 32);

							SendCharList(ZonePasses[i].LoggedIn);
						}
						SaveAccounts();
					} else {
						NeedToDelete = true;
					}
				}

			}
		}
	}
}

void cACServer::SendCharList(int UserParsing)
{
	cMessageHeader tph2;
//	tph2.m_dwSequence = 0x000D648B;
	tph2.m_wUnknown1 = 0x0004;	

	BYTE PlayerList[0x200];
	BYTE *PackPointer = &PlayerList[0];

	DWORD tpdword;

	tpdword = 0x0000F658;			memcpy(PackPointer, &tpdword, 4);	PackPointer += 4;
	tpdword = 0x00000000;			memcpy(PackPointer, &tpdword, 4);	PackPointer += 4;
	
	int NumChars = 0;
	for (int i=0;i<5;i++)
		if (ConnUser[UserParsing].Chars[i].GUID)
			NumChars++;
									memcpy(PackPointer, &NumChars, 4);	PackPointer += 4;

	BYTE NameLen;
	for (i=0;i<5;i++)
	{
		if (ConnUser[UserParsing].Chars[i].GUID)
		{
			tpdword = ConnUser[UserParsing].Chars[i].GUID & 0x7FFFFFFF;
				memcpy(PackPointer,&tpdword,4); PackPointer += 4;	//GUID

			NameLen = strlen(ConnUser[UserParsing].Chars[i].Name) + 1;
				memcpy(PackPointer,&NameLen,sizeof(NameLen)); PackPointer += sizeof(NameLen);	//NameLen

			*PackPointer = 0; PackPointer++;												//0
			NameLen--; memcpy(PackPointer,&ConnUser[UserParsing].Chars[i].Name,NameLen); PackPointer += NameLen;	//Name
			*PackPointer = 0; PackPointer++;												//0
			
			int Tpl = ((PackPointer-&PlayerList[0])%4); if (Tpl) Tpl=4-Tpl;			//Padding
			for (int ii=0;ii<Tpl;ii++) {	*PackPointer = 0; PackPointer++; }		//"

			//Time remaining till perma-delete
			if (ConnUser[UserParsing].Chars[i].GUID & 0x80000000)
				tpdword = ZonePasses[ConnUser[UserParsing].ZoneNum].Secs2Del[i];
			else
				tpdword = 0;

					memcpy(PackPointer, &tpdword, 4);	PackPointer += 4;
		}
	}

	tpdword = 0;
	for (i=0;i<5;i++)
		if (ConnUser[UserParsing].Chars[i].GUID & 0x80000000)
			tpdword++;
									memcpy(PackPointer,&tpdword,4);	PackPointer += 4;		//0 - DWORD
	tpdword = 5;					memcpy(PackPointer,&tpdword,4);	PackPointer += 4;		//5 - DWORD
	tpdword = 0xBEEFBEEF;			memcpy(PackPointer,&tpdword,4);	PackPointer += 4;		//BEEFBEEF - DWORD
	memcpy(PackPointer,&ConnUser[UserParsing].ZoneName[0],0x14);	PackPointer += 20;		//Zone Name - 20 Chars
	tpdword = 0;					memcpy(PackPointer,&tpdword,4);	PackPointer += 4;		//0 - DWORD
	Send802(&tph2, &PlayerList[0], (int) (PackPointer - &PlayerList[0]), UserParsing);

//MOTD
//	tph2.m_dwSequence = 0x000D648C;
	tph2.m_wUnknown1 = 0x0004;	

	PackPointer = &PlayerList[0x0];

	NumConnected = 0;
	for (int hh=0;hh<128;hh++)
	{
		if (ConnUser[hh].Connected)
			NumConnected++;
	}

	sprintf(MOTDa, "Hello, %s, You have successfully joined a server running an Alpha copy of the AC Server Emulator!\nThere are currently: %i Clients Connected.\n\n", ConnUser[UserParsing].ZoneName, NumConnected);

	DWORD Zero = 0x0000F65A;				memcpy(PackPointer,&Zero,4);	PackPointer += 4;		//F65A - DWORD
	unsigned short strlen1 = strlen(MOTDa)+1, strlen2 = strlen(MOTDb)+1;
	memcpy(PackPointer,&strlen1,2);		PackPointer += 2;									//String1Len - SHORT
	memcpy(PackPointer,&MOTDa,strlen1);	PackPointer += strlen1;								//String1Len - SHORT
	int Tpl = ((PackPointer-&PlayerList[0])%4); if (Tpl) Tpl=4-Tpl;			//Padding
	for (int ii=0;ii<Tpl;ii++) {	*PackPointer = 0; PackPointer++; }		//"

	memcpy(PackPointer,&strlen2,2);		PackPointer += 2;									//String1Len - SHORT
	memcpy(PackPointer,&MOTDb,strlen2);	PackPointer += strlen2;								//String1Len - SHORT
	Tpl = ((PackPointer-&PlayerList[0])%4); if (Tpl) Tpl=4-Tpl;			//Padding
	for (ii=0;ii<Tpl;ii++) {	*PackPointer = 0; PackPointer++; }		//"

	Send802(&tph2, &PlayerList[0], (int) (PackPointer - &PlayerList[0]), UserParsing);
}

void cACServer::Send802(cMessageHeader *msghead, BYTE *data, int datalen, int User)
{
	int numpacks = (int) (datalen / 0x1C0);
	if (datalen % 0x1c0) numpacks++;

	unsigned char outbuf[0x1E4];

	cServerPacketHeader packhead;
	packhead.m_dwFlags = 0x00000802;
	packhead.m_dwServerID = 0x0000000C;
	packhead.m_bTable = 2;
	packhead.m_bTime = ConnUser[User].bTime;
	packhead.m_dwCRC = 0xBAADF00D;  //ignore for now
	
	msghead->m_dwObjectID = 0x80000000;
	
	for (int i=0;i<numpacks;i++)
	{
		ConnUser[User].curSeq++;
		packhead.m_dwSequence = ConnUser[User].curSeq;
		msghead->m_wFragmentCount = numpacks;
		msghead->m_wFragmentIndex = i;

		if (i < (numpacks-1))
		{
			msghead->m_wFragmentLength = 0x1D0;
			packhead.m_wTotalSize = 0x1D0;
			
			memcpy(&outbuf[0], &packhead, sizeof(cServerPacketHeader));
			memcpy(&outbuf[sizeof(cServerPacketHeader)], msghead, sizeof(cMessageHeader));
			memcpy(&outbuf[sizeof(cServerPacketHeader)+sizeof(cMessageHeader)], data+(i*0x1C0), 0x1C0);

			sendto(charSocket,(char *) &outbuf[0],0x1E4,NULL,(sockaddr *)&ConnUser[User].sockaddy,sizeof(sockaddr_in));
		} else {
			msghead->m_wFragmentLength = 0x10 + datalen % 0x1C0;
			packhead.m_wTotalSize = 0x10 + datalen % 0x1C0;
			
			memcpy(&outbuf[0], &packhead, sizeof(cServerPacketHeader));
			memcpy(&outbuf[sizeof(cServerPacketHeader)], msghead, sizeof(cMessageHeader));
			memcpy(&outbuf[sizeof(cServerPacketHeader)+sizeof(cMessageHeader)], data+(i*0x1C0), datalen % 0x1C0);

			sendto(charSocket,(char *) &outbuf[0],0x24 + (datalen % 0x1C0),NULL,(sockaddr *)&ConnUser[User].sockaddy,sizeof(sockaddr_in));
		}
	}

	msghead->m_dwSequence++;
}

void cACServer::DisconnectUser(int User)
{
	if (ConnUser[User].Connected == false)
		return;

	ConnUser[User].ObjectCache.clear();

	ConnUser[User].Connected = false;

	int NumConn = 0;
	for (int hh=0;hh<128;hh++)
	{
		if (ConnUser[hh].Connected)
			NumConn++;
	}

	ZonePasses[ConnUser[User].ZoneNum].LoggedIn = (WORD) -1;

	UpdateCharInfo(User, "Not Connected");

	//Recalc MaxUsers
	for (int i=127;i>=0;i--)
	{
		if (ConnUser[i].Connected)
		{	MaxUsers = i+1;	break; }
	}

	if (ConnUser[User].Char == 0)
		return;

	SaveCharacter(User);

	LBObjects[ConnUser[User].Char->Loc.landblock >> 16].erase(ConnUser[User].Char->GUID);

	ObjectList.erase(ConnUser[User].Char->GUID);

	//Return him to char select screen
	cMessageHeader tph2;
	tph2.m_dwSequence = 0x081A9900;
	tph2.m_wUnknown1 = 0x0004;

	DWORD tph3 = 0x0000F653;

	Send802(&tph2, (BYTE *) &tph3, sizeof(tph3), User);

	//Disconnect Him
	ConnUser[User].Connected = false;

	sprintf(sayit, "Player %s Disconnected!", ConnUser[User].Char->Name);
	ServerMessage(GLOBAL_MESSAGE, sayit, COLOR_GREEN);

	//Delete him from other people
//	tph2.m_dwSequence = 0;
//	tph2.m_wUnknown1 = 0x0004;
	RemoveItem(ConnUser[User].Char->GUID);

//	memcpy(&DESTROY_ENTITY[4],&ConnUser[User].Char->GUID,4);
//	for (int iii=0;iii<MaxUsers;iii++)
//	{
//		if ((ConnUser[iii].Connected) && (ConnUser[iii].State == 6) && (iii != User))
//			Send802(&tph2, &DESTROY_ENTITY[0], sizeof(DESTROY_ENTITY), iii);
//	}

	ConnUser[User].Char = 0;
}

void cACServer::UpdateCharInfo(int User, char * NewText)
{
	SendDlgItemMessage(MainWnd, IDC_CHARLIST, LB_DELETESTRING, User+1, 0);

	char TpStr[100];
	strcpy(ConnUser[User].Status, NewText);
	if (ConnUser[User].Connected)
	{
		sprintf(TpStr, "%i\t%i.%i.%i.%i:%i\t%s", User,
			ConnUser[User].sockaddy.sin_addr.S_un.S_un_b.s_b1,
			ConnUser[User].sockaddy.sin_addr.S_un.S_un_b.s_b2,
			ConnUser[User].sockaddy.sin_addr.S_un.S_un_b.s_b3,
			ConnUser[User].sockaddy.sin_addr.S_un.S_un_b.s_b4,
			ntohs(ConnUser[User].sockaddy.sin_port),
			NewText);
	} else {
		sprintf(TpStr, "%i\tN/A\t\t\t%s", User, NewText);
	}
	SendDlgItemMessage(MainWnd, IDC_CHARLIST, LB_INSERTSTRING, User+1, (WPARAM) &TpStr[0]);
}

void cACServer::ServerMessage(int User, char *Text, DWORD Color)
{
	try {
		cMessageHeader tph2;
		tph2.m_dwSequence = 0x00000000;
		tph2.m_wUnknown1 = 0x0004;

		BYTE TpMes[1024]; BYTE * PackPtr = &TpMes[0];
		DWORD tpf;
		int outlen;
		tpf = 0x0000F62C;		memcpy(PackPtr,&tpf,4);	PackPtr += 4;
		GenString(Text, &outlen, PackPtr); PackPtr += outlen;
		tpf = Color;		memcpy(PackPtr,&tpf,4);	PackPtr += 4;
		if ((User >= 0) && (User < 128))
		{
			Send802(&tph2, &TpMes[0], (int) (PackPtr - &TpMes[0]), User);
		} else if (User == GLOBAL_MESSAGE) {
			//Global Message...
			for (int i=0;i<MaxUsers;i++)
			{
				if ((ConnUser[i].Connected) && (ConnUser[i].State >= 5))
					Send802(&tph2, &TpMes[0], (int) (PackPtr - &TpMes[0]), i);
			}
		} else if ((User > -128) && (User < 0)) {
			//Global Message except User
			for (int i=0;i<MaxUsers;i++)
			{
				if ((ConnUser[i].Connected) && (ConnUser[i].State >= 5) && (i != (User*-1)-1))
					Send802(&tph2, &TpMes[0], (int) (PackPtr - &TpMes[0]), i);
			}
		}
	} catch (char * ) {
		//Meh...
		
	}
}

void cACServer::ReorgCharFile()
{
	FILE *in = fopen("CharList.dat","rb");
	fseek(in, 0, SEEK_END);
	int filelen = ftell(in);
	fseek(in, 0, SEEK_SET);
	
	cWorldObject_Char *OrgList = new cWorldObject_Char[filelen/sizeof(cWorldObject_Char)];
//	new cWorldObject_Char[filelen/sizeof(cWorldObject_Char)];

	fread(OrgList, filelen, 1, in);

	fclose(in);

	FILE *newlist = fopen("CharList.dat", "wb");
	
	for (int i=0;i<(int) (filelen/sizeof(cWorldObject_Char));i++)
	{
		if (OrgList[i].GUID != 0)
			fwrite(&OrgList[i], sizeof(cWorldObject_Char), 1, newlist);
	}
	
	fclose(newlist);
}

void cACServer::SaveCharacter(int CharNum)
{
	FILE *charread = fopen("CharList.dat","r+b");

	fseek(charread, 0, SEEK_END);
	int numchars = ftell(charread)/(SIZEOFCHAR+68);
	fseek(charread, 0, SEEK_SET);

	DWORD GUIDtemp;
	for (int j=0;j<numchars;j++)
	{
		fseek(charread, j*(SIZEOFCHAR+68), SEEK_SET);
		fread(&GUIDtemp, 4, 1, charread);
		if (GUIDtemp == ConnUser[CharNum].Char->GUID)
		{
			fseek(charread, j*(SIZEOFCHAR+68), SEEK_SET);

			BYTE TPlog[5000]; int charsize = ConnUser[CharNum].Char->Serialize(TPlog);
			fwrite(&ConnUser[CharNum].Char->GUID, 4, 1, charread);
			fwrite(ConnUser[CharNum].Char->Name, 32, 1, charread);
			fwrite(&ConnUser[CharNum].Char->Loc, sizeof(Location_t), 1, charread);
			fwrite(TPlog, charsize, 1, charread);
			
//			fwrite(ConnUser[CharNum].Char, sizeof(cWorldObject_Char), 1, charread);
			j = numchars;
		}
	}

	fclose(charread);
}

int cACServer::Generate_F7B0_13(BYTE * OutPack, int User)
{
	BYTE *PackPointer = OutPack;
	DWORD tpd;	WORD tpw;
	
	//F7b0 header
	tpd = 0xF7B0;		memcpy(PackPointer, &tpd, 4);	PackPointer += 4;
						memcpy(PackPointer, &ConnUser[User].Char->GUID, 4);	PackPointer += 4;
						memcpy(PackPointer, &ConnUser[User].EventCount, 4);	PackPointer += 4;
	tpd = 0x0013;		memcpy(PackPointer, &tpd, 4);	PackPointer += 4;		//13 = Login Char
	ConnUser[User].EventCount++;
	
	//On the the actual packet...
	tpd = 0x001B;		memcpy(PackPointer, &tpd, 4);	PackPointer += 4;		//loginMask1
	tpd = 0x000A;		memcpy(PackPointer, &tpd, 4);	PackPointer += 4;		//unknown1
	
	//count1
	tpw = 0x0007;		memcpy(PackPointer, &tpw, 2);	PackPointer += 2;		//count for next section
	tpw = 0x0040;		memcpy(PackPointer, &tpw, 2);	PackPointer += 2;		//unknown for this
	
	//Burden, calc later..
	tpd = 0x0005;		memcpy(PackPointer, &tpd, 4);	PackPointer += 4;		//5 = burden
	tpd =      1;		memcpy(PackPointer, &tpd, 4);	PackPointer += 4;		//1 = ?
	//Pyreals, calc later
	tpd = 0x0014;		memcpy(PackPointer, &tpd, 4);	PackPointer += 4;		//14 = pyreals
	tpd =      0;		memcpy(PackPointer, &tpd, 4);	PackPointer += 4;		//0
	//Total Xp
	tpd = 0x0015;		memcpy(PackPointer, &tpd, 4);	PackPointer += 4;		//15 = total xp
						memcpy(PackPointer, &ConnUser[User].Char->TotalXP, 4);	PackPointer += 4;
	//Unassigned XP
	tpd = 0x0016;		memcpy(PackPointer, &tpd, 4);	PackPointer += 4;		//16 = unassigned xp
						memcpy(PackPointer, &ConnUser[User].Char->UnassignedXP, 4);	PackPointer += 4;
	//Unassigned Skill Points
	tpd = 0x0018;		memcpy(PackPointer, &tpd, 4);	PackPointer += 4;		//18 = unassigned skill points
						memcpy(PackPointer, &ConnUser[User].Char->SkillCredits, 4);	PackPointer += 4;
	//Level, calc later....
	tpd = 0x0019;		memcpy(PackPointer, &tpd, 4);	PackPointer += 4;		//19 = Level
						memcpy(PackPointer, &ConnUser[User].Char->Level, 4);	PackPointer += 4;
	//Rank, calc later
	tpd = 0x001e;		memcpy(PackPointer, &tpd, 4);	PackPointer += 4;		//1e = Rank
	tpd = 0x0000;		memcpy(PackPointer, &tpd, 4);	PackPointer += 4;

	//count2	
	tpw = 0x0005;		memcpy(PackPointer, &tpw, 2);	PackPointer += 2;		//no idea...
	tpw = 0x0020;		memcpy(PackPointer, &tpw, 2);	PackPointer += 2;		//no idea...
	//count2 vector here... i.e. nothing yet

	//hax0r
	memcpy(PackPointer, &CHAR_DATA[0x40], 0x28);	PackPointer += 0x28;

	//strings
	tpw = 0x0004;		memcpy(PackPointer, &tpw, 2);	PackPointer += 2;
	tpw = 0x0010;		memcpy(PackPointer, &tpw, 2);	PackPointer += 2;		//I think the type is 1...

	//Char Name
	tpd = 0x0001;		memcpy(PackPointer, &tpd, 4);	PackPointer += 4;
						GenString(ConnUser[User].Char->Name, (int *) &tpd, PackPointer);	PackPointer += tpd;
	//Gender
	tpd = 0x0003;		memcpy(PackPointer, &tpd, 4);	PackPointer += 4;
	char Gender[7];
	if (ConnUser[User].Char->Gender == 0)
		sprintf(Gender, "Female");
	if (ConnUser[User].Char->Gender == 1)
		sprintf(Gender, "Male");
	GenString(Gender, (int *) &tpd, PackPointer);	PackPointer += tpd;

	//Race
	char Race[12];
	tpd = 0x0004;		memcpy(PackPointer, &tpd, 4);	PackPointer += 4;
	if (ConnUser[User].Char->Race == 0)
		sprintf(Race, "Aluvian");
	if (ConnUser[User].Char->Race == 1)
		sprintf(Race, "Gharun'Dim");
	if (ConnUser[User].Char->Race == 2)
		sprintf(Race, "Sho");
	GenString(Race, (int *) &tpd, PackPointer);	PackPointer += tpd;

	//Class	- "Server Tester" for now... ;-)
	tpd = 0x0005;		memcpy(PackPointer, &tpd, 4);	PackPointer += 4;
						GenString("Server Tester", (int *) &tpd, PackPointer);	PackPointer += tpd;

	//count4
	tpw = 0x0001;		memcpy(PackPointer, &tpw, 2);	PackPointer += 2;		//no idea...
	tpw = 0x0020;		memcpy(PackPointer, &tpw, 2);	PackPointer += 2;		//no idea...
	//count4 vector here... i.e. nothing yet

	//sec4 stuff
	tpd = 0x0004;		memcpy(PackPointer, &tpd, 4);	PackPointer += 4;		//
	tpd = 0x30000000;	memcpy(PackPointer, &tpd, 4);	PackPointer += 4;		//

	//Loginmask1 info goes here

	tpd = 0x0103;		memcpy(PackPointer, &tpd, 4);	PackPointer += 4;		//Loginmask2
	tpd = 0x0001;		memcpy(PackPointer, &tpd, 4);	PackPointer += 4;		//unknown14 - always 1
	tpd = 0x01ff;		memcpy(PackPointer, &tpd, 4);	PackPointer += 4;		//attributemask - always 0x1ff
	
	//Primary Stats						
	for (int i=0;i<6;i++)
	{
		if (i == 3)
		{
			memcpy(PackPointer, &ConnUser[User].Char->CurrentStat[2], 4);	PackPointer += 4;
			memcpy(PackPointer, &ConnUser[User].Char->InitialStat[2], 4);	PackPointer += 4;
			memcpy(PackPointer, &ConnUser[User].Char->XPIntoStat[2], 4);		PackPointer += 4;
		} else if (i == 2) {
			memcpy(PackPointer, &ConnUser[User].Char->CurrentStat[3], 4);	PackPointer += 4;
			memcpy(PackPointer, &ConnUser[User].Char->InitialStat[3], 4);	PackPointer += 4;
			memcpy(PackPointer, &ConnUser[User].Char->XPIntoStat[3], 4);		PackPointer += 4;
		} else {
			memcpy(PackPointer, &ConnUser[User].Char->CurrentStat[i], 4);	PackPointer += 4;
			memcpy(PackPointer, &ConnUser[User].Char->InitialStat[i], 4);	PackPointer += 4;
			memcpy(PackPointer, &ConnUser[User].Char->XPIntoStat[i], 4);		PackPointer += 4;
		}
	}

	//Secondary Stats
	for (i=0;i<3;i++)
	{
		memcpy(PackPointer, &ConnUser[User].Char->SecondaryStatInc[i], 4);		PackPointer += 4;
		tpd = 0;	memcpy(PackPointer, &tpd, 4);		PackPointer += 4;	//?... always 0 afawct
		memcpy(PackPointer, &ConnUser[User].Char->XPIntoSecondaryStat[i], 4);		PackPointer += 4;
		memcpy(PackPointer, &ConnUser[User].Char->CurrentSecondaryStat[i], 4);		PackPointer += 4;
	}

	//Skillcount
	tpw = 0x0023;		memcpy(PackPointer, &tpw, 2);	PackPointer += 2;		//count
	tpw = 0x0020;		memcpy(PackPointer, &tpw, 2);	PackPointer += 2;		//unknown

	for (i=1;i<40;i++)
	{
		if (ConnUser[User].Char->SkillTrain[i] > 0)
		{
			memcpy(PackPointer, &i, 4);	PackPointer += 4;		//Skill number
			memcpy(PackPointer, &ConnUser[User].Char->SkillInc[i], 4);	PackPointer += 4;		//Skill number
			memcpy(PackPointer, &ConnUser[User].Char->SkillTrain[i], 4);	PackPointer += 4;		//Trained Status
			memcpy(PackPointer, &ConnUser[User].Char->SkillXP[i], 4);	PackPointer += 4;		//Total XP into skill
			memcpy(PackPointer, &ConnUser[User].Char->SkillFreeXP[i], 4);	PackPointer += 4;	//Free XP at gen
			tpd = 0x0000;	memcpy(PackPointer, &tpd, 4);	PackPointer += 4;	//unknown2
			
			//double thingy
			tpd = 0x889088f8;	memcpy(PackPointer, &tpd, 4);	PackPointer += 4;
			tpd = 0x4161aab6;	memcpy(PackPointer, &tpd, 4);	PackPointer += 4;
		}
	}

	//Loginmask2 time
	//100 - spellbook
	WORD numspells = 0;
	for (i=0;i<96;i++)
	{
		for (DWORD tpdd=ConnUser[User].Char->SpellsLearned[i];tpdd > 0;tpdd >>= 1)
		{
			if (tpdd & 1)
				numspells++;
		}
	}
						memcpy(PackPointer, &numspells, 2);	PackPointer += 2;		//count
	tpw = 0x0040;		memcpy(PackPointer, &tpw, 2);	PackPointer += 2;		//spellcountunknown

	int tpinc;	float tpcharge = 1.0f;
	for (i=0;i<96;i++)
	{
		tpinc = 0;
		for (DWORD TpSpell = ConnUser[User].Char->SpellsLearned[i]; TpSpell > 0; TpSpell >>= 1)
		{
			if (TpSpell & 1)
			{
				tpd = (i << 5) | tpinc;		memcpy(PackPointer, &tpd, 4);	PackPointer += 4;		//spell ID
											memcpy(PackPointer, &tpcharge, 4);	PackPointer += 4;		//charge
				tpd = 0;					memcpy(PackPointer, &tpd, 4);	PackPointer += 4;		//unknown2
				tpd = 0;					memcpy(PackPointer, &tpd, 4);	PackPointer += 4;		//unknown3
			}
			tpinc++;
		}
	}
	
	//200 - enchantments... whoooa there cowboy

	DWORD Numshorts = 0;
	for (i=0;i<10;i++)
		if (ConnUser[User].Char->ShortCut[i])
			Numshorts++;

	if (Numshorts)
		tpd = 0x0005;
	else
		tpd = 0x0004;
						memcpy(PackPointer, &tpd, 4);	PackPointer += 4;		//loginmask3

	//4, character options
						//memcpy(PackPointer, &ConnUser[User].Char->Options, 4);	PackPointer += 4;
	tpd = 0x0004E56A;	memcpy(PackPointer, &tpd, 4);	PackPointer += 4;		//loginmask3
	//hax0r

	if (Numshorts)
	{
		//1, shortcut bar
		memcpy(PackPointer, &Numshorts, 4);	PackPointer += 4;
		for (i=0;i<10;i++)
			if (ConnUser[User].Char->ShortCut[i])
			{
				memcpy(PackPointer, &i, 4);	PackPointer += 4;									//Position
				memcpy(PackPointer, &ConnUser[User].Char->ShortCut[i], 4);	PackPointer += 4;	//Object
				tpd = 0;	memcpy(PackPointer, &tpd, 4);	PackPointer += 4;					//Unknown - 0
			}
	}

	//Spellbars
	for (i=0;i<5;i++)
	{
		DWORD numspells = 0;
		for (numspells=0;ConnUser[User].Char->SpellBar[i][numspells] > 0;numspells++) { }

		memcpy(PackPointer, &numspells, 4);	PackPointer += 4;
		for (int j=0;j<numspells;j++)
		{
			memcpy(PackPointer, &ConnUser[User].Char->SpellBar[i][j], 4);	PackPointer += 4;
		}
	}

	//comp buyer...
	
	//Inventory
	DWORD numinv = 0;
	for (i=0;i<7;i++)
		if (ConnUser[User].Char->SidePacks[i])
			numinv++;
	for (i=0;i<102;i++)
		if (ConnUser[User].Char->MainPack[i])
			numinv++;

	memcpy(PackPointer, &numinv, 4);	PackPointer += 4;
	for (i=0;i<7;i++)
		if (ConnUser[User].Char->SidePacks[i])
		{
			memcpy(PackPointer, &ConnUser[User].Char->SidePacks[i], 4);	PackPointer += 4;
			tpd = 1;	memcpy(PackPointer, &tpd, 4);	PackPointer += 4;		//IsContainer = 1
		}
	for (i=0;i<102;i++)
		if (ConnUser[User].Char->MainPack[i])
		{
			memcpy(PackPointer, &ConnUser[User].Char->MainPack[i], 4);	PackPointer += 4;
			tpd = 0;	memcpy(PackPointer, &tpd, 4);	PackPointer += 4;		//IsContainer = 0
		}

	//Equipped Shizzit
/*	DWORD numequip = 0;
	for (i=0;i<25;i++)
		if (ConnUser[User].Char->Equipped[i])
			numequip++;
*/
	memcpy(PackPointer, &numinv, 4);	PackPointer += 4;
	for (i=0;i<25;i++)
		if (ConnUser[User].Char->Equipped[i])
		{
			memcpy(PackPointer, &ConnUser[User].Char->Equipped[i], 4);	PackPointer += 4;
			tpd = (1 << i);	memcpy(PackPointer, &tpd, 4);	PackPointer += 4;		//Coverage
			tpd = 0;	memcpy(PackPointer, &tpd, 4);	PackPointer += 4;		//unknown3
		}

	return((int) (PackPointer - OutPack));
}

void cACServer::LoadObjects()
{
	sprintf(sayit, "Loading Objects.Dat..."); LogDisp(sayit);

	FILE *in = fopen("Objects.dat","rb");
	if (!in)
	{
		sprintf(sayit, "Objects.Dat Empty!  Initializing with an empty empty world."); LogDisp(sayit);
		return;
	}

	BYTE ObjData[4096];
	cWorldObject *tpObj = (cWorldObject *) ObjData;
	
	int errtest;

	cWorldObject *tpo;

	while (!feof(in))
	{
		DWORD ObjType;  errtest = fread(&ObjType, 4, 1, in);
	
		if (!errtest)
		{
			fclose(in);
			sprintf(sayit, "Objects.Dat Loaded!"); LogDisp(sayit);
			return;
		}

		switch (ObjType)
		{
		case OBJECT_LIFESTONE:
			tpo = new cWorldObject_LS();
			break;
		case OBJECT_OBJECTID:
			tpo = new cWorldObject_ObjectID();
			break;
		case OBJECT_PORTAL:
			tpo = new cWorldObject_Portal();
			break;
		case OBJECT_CHARACTER:
			//Ignore
			MessageBox(NULL, "Fatal Error: Character found in objects.dat...", "Fatal Error", MB_OK);
			break;
		default:
			//eep... bad.
			MessageBox(NULL, "Fatal Error: Unknown Object type in Objects.Dat.  Please Restore Objects.Dat.  Objects.Dat loading halted...", "Fatal Error", MB_OK);
			return;
		}

		if (ObjType != OBJECT_CHARACTER)
		{
			fread(ObjData, tpo->Size, 1, in);
			memcpy(&tpo->GUID, ObjData, 4);
			memcpy(tpo->Name, &ObjData[4], 32);
			memcpy(&tpo->Loc, &ObjData[4+32], 4);
			tpo->LoadFrom(&ObjData[4+32+32]);
			ObjectList[tpo->GUID] = tpo;
			LBObjects[tpo->Loc.landblock >> 16][tpo->GUID] = tpo;
		}

		if (ObjType == OBJECT_PORTAL)
			Portals[tpo->Loc.landblock >> 16][tpo->GUID] = (cWorldObject_Portal *) tpo;
	}
}

void cACServer::SaveObjects()
{
//	DeleteFile("Objects.Bak");
//	rename("Objects.Dat", "Objects.Bak");

	FILE *out = fopen("Objects.Dat","wb");
	if (!out)
	{
		//bad...
		MessageBox(NULL, "Can't open objects.dat for writing... very bad...", "Fatal Error", MB_OK);
		return;
	}
	
	BYTE SerData[4096];	int SerSize;

	for (std::map<DWORD, cWorldObject *>::iterator i = ObjectList.begin(); i != ObjectList.end(); i++)
	{
		if ((i->second) && (i->second->Type != OBJECT_CHARACTER))
		{
			fwrite(&i->second->Type, 4, 1, out);
			fwrite(&i->second->GUID, 4, 1, out);
			fwrite(i->second->Name, 32, 1, out);
			fwrite(&i->second->Loc, 32, 1, out);

			SerSize = i->second->Serialize(SerData);
			if (SerSize)
				fwrite(SerData, SerSize, 1, out);
		}
	}

	fclose(out);
}

void cACServer::SendLandblock(int User, WORD Landblock)
{
	int packlen;
	BYTE TpP[500];
	cMessageHeader tph2;
	tph2.m_wUnknown1 = 3;
	
	for (std::map<DWORD, cWorldObject *>::iterator i = LBObjects[Landblock].begin(); i != LBObjects[Landblock].end(); i++)
	{
		if ((i->second->Type != 0) && (i->second->GUID != ConnUser[User].Char->GUID))
		{
			packlen = i->second->GenerateCreatePacket(TpP);
			Send802(&tph2, TpP, packlen, User);
		}
	}
}

void cACServer::MoveUser(int User, Location_t *loc, bool Portal, bool Override)
{
	for (std::map<DWORD, cWorldObject *>::iterator i = Portals[loc->landblock >> 16].begin(); i != Portals[loc->landblock >> 16].end(); i++)
	{
		if (GetDistance(loc, &i->second->Loc) < 0.01)
		{
			MoveUser(User, &((cWorldObject_Portal *)i->second)->DestLoc, true, false);
//			ServerMessage(User, "Entered Portal... Teleporting...", COLOR_RED);
		}
	}

	float heading = acos(loc->a);
	if (loc->w > 0) heading = PI - heading;
	heading *= 2;
	ConnUser[User].PointX = sin(heading);
	ConnUser[User].PointY = cos(heading);

	if (!ConnUser[User].Char)
		return;

	WORD OldLB = ConnUser[User].Char->Loc.landblock >> 16, NewLB = loc->landblock >> 16;
	
	memcpy(&ConnUser[User].Char->Loc, loc, sizeof(Location_t));

	cMessageHeader tph2;

	DWORD tpf2 = 0x0000F748; memcpy (&MOVE_ENTITY[0x00],&tpf2,4);
	memcpy(&MOVE_ENTITY[0x4], &ConnUser[User].Char->GUID, 4);
	tpf2 = 0x00000034; memcpy (&MOVE_ENTITY[0x08],&tpf2,4);
	memcpy(&MOVE_ENTITY[0x0C], &ConnUser[User].Char->Loc, 4*5);
	memcpy(&MOVE_ENTITY[0x20], &ConnUser[User].Char->Loc.w, 4);

	if (Portal)
		ConnUser[User].PortalCount++;
	if (Override)
		ConnUser[User].OverrideCount++;
	
	memcpy (&MOVE_ENTITY[0x24],&ConnUser[User].Char->NumLogins,2);
	memcpy (&MOVE_ENTITY[0x26],&ConnUser[User].move_count,2);
	memcpy (&MOVE_ENTITY[0x28],&ConnUser[User].PortalCount,2);
	memcpy (&MOVE_ENTITY[0x2A],&ConnUser[User].OverrideCount,2);

	tph2.m_wUnknown1 = 3;
	for (int iii=0;iii<MaxUsers;iii++)
	{
		tph2.m_dwSequence = ConnUser[User].move_count;
		if ((ConnUser[iii].Connected) && ((ConnUser[iii].State == 6) || (iii == User)))
			Send802(&tph2, &MOVE_ENTITY[0], sizeof(MOVE_ENTITY), iii);
		tph2.m_dwSequence++;
	}
	ConnUser[User].move_count++;

	if (OldLB != NewLB)
	{
		LBObjects[OldLB].erase(ConnUser[User].Char->GUID);
		LBObjects[NewLB][ConnUser[User].Char->GUID] = (cWorldObject *) ConnUser[User].Char;


		if (OldLB == NewLB - 1) {
			SendLandblock(User, NewLB - 1);
			SendLandblock(User, NewLB - 1 - 256);
			SendLandblock(User, NewLB - 1 + 256);
		} else if (OldLB == NewLB + 1) {
			SendLandblock(User, NewLB + 1);
			SendLandblock(User, NewLB + 1 - 256);
			SendLandblock(User, NewLB + 1 + 256);
		} else if (OldLB == NewLB - 256) {
			SendLandblock(User, NewLB - 256 - 1);
			SendLandblock(User, NewLB - 256);
			SendLandblock(User, NewLB - 256 + 1);
		} else if (OldLB == NewLB + 256) {
			SendLandblock(User, NewLB + 256 - 1);
			SendLandblock(User, NewLB + 256);
			SendLandblock(User, NewLB + 256 + 1);
//Diagonals Now
		} else if (OldLB == NewLB + 256 + 1) {
			SendLandblock(User, NewLB + 256 + 1);
			SendLandblock(User, NewLB + 256 + 1 - 256);
			SendLandblock(User, NewLB + 256 + 1 - 256 - 256 );
			SendLandblock(User, NewLB + 256 + 1 - 1);
			SendLandblock(User, NewLB + 256 + 1 - 1 - 1);
		} else if (OldLB == NewLB + 256 - 1) {
			SendLandblock(User, NewLB + 256 - 1);
			SendLandblock(User, NewLB + 256 - 1 - 256);
			SendLandblock(User, NewLB + 256 - 1 - 256 - 256 );
			SendLandblock(User, NewLB + 256 - 1 + 1);
			SendLandblock(User, NewLB + 256 - 1 + 1 + 1);
		} else if (OldLB == NewLB - 256 + 1) {
			SendLandblock(User, NewLB - 256 + 1);
			SendLandblock(User, NewLB - 256 + 1 + 256);
			SendLandblock(User, NewLB - 256 + 1 + 256 + 256 );
			SendLandblock(User, NewLB - 256 + 1 - 1);
			SendLandblock(User, NewLB - 256 + 1 - 1 - 1);
		} else if (OldLB == NewLB - 256 - 1) {
			SendLandblock(User, NewLB - 256 - 1);
			SendLandblock(User, NewLB - 256 - 1 + 256);
			SendLandblock(User, NewLB - 256 - 1 + 256 + 256 );
			SendLandblock(User, NewLB - 256 - 1 + 1);
			SendLandblock(User, NewLB - 256 - 1 + 1 + 1);
		} else {
			SendLandblock(User, NewLB);
			SendLandblock(User, NewLB - 1);
			SendLandblock(User, NewLB + 1);
			SendLandblock(User, NewLB - 256);
			SendLandblock(User, NewLB - 256 - 1);
			SendLandblock(User, NewLB - 256 + 1);
			SendLandblock(User, NewLB + 256);
			SendLandblock(User, NewLB + 256 - 1);
			SendLandblock(User, NewLB + 256 + 1);
		}
	}
}

void cACServer::SendAnim(int User, WORD AnimNum)
{
	cMessageHeader tph2;

	ConnUser[User].AnimCount++;

	cAnimStruct ASt;
	ASt.dwf74c = 0x0000F74C;
	ASt.dwGUID = ConnUser[User].Char->GUID;
	ASt.wNumLogins = ConnUser[User].Char->NumLogins;
	ASt.wNumInteractions = ConnUser[User].move_count;
	ASt.wNumAnimations = ConnUser[User].AnimCount;
	ASt.wFlag = 0;
	ASt.wUnk1 = 0;
	ASt.wAnimation_Family = 0x3D;
	ASt.wUnk2 = 0x80;
	ASt.wUnk3 = 0;
	ASt.wAnimation_Seqnum = ConnUser[User].AnimCount;
	ASt.wAnimation_to_Play = (WORD) AnimNum;
	ASt.fPlaySpeed = 1.0f;

	tph2.m_dwSequence = ConnUser[User].move_count;
	tph2.m_wUnknown1 = 3;

	ConnUser[User].move_count++;

	for (int i=0;i<MaxUsers;i++)
	{
		if (ConnUser[i].Connected)
			Send802(&tph2, (BYTE *) &ASt, sizeof(ASt), i);
	}
}

void cACServer::PointAt(int User, DWORD GUIDAt)
{
	cMessageHeader tph2;

	ConnUser[User].AnimCount++;

	cAnimStructEx ASt;
	ASt.dwf74c = 0x0000F74C;
	ASt.dwGUID = ConnUser[User].Char->GUID;
	ASt.wNumLogins = ConnUser[User].Char->NumLogins;
	ASt.wNumInteractions = ConnUser[User].move_count;
	ASt.wNumAnimations = ConnUser[User].AnimCount;
	ASt.wFlag = 0;
	ASt.wUnk1 = 0;
	ASt.wAnimation_Family = 0x3D;

	ASt.dwf74c = 0x0000F74C;
	ASt.dwGUID = ConnUser[User].Char->GUID;
	ASt.wNumLogins = ConnUser[User].Char->NumLogins;
	ASt.wNumInteractions = ConnUser[User].move_count;
	ASt.wNumAnimations = ConnUser[User].AnimCount;
	ASt.wFlag = 0;
	ASt.wUnk1 = 0x0008;
	ASt.wAnimation_Family = 0x3D;
	ASt.GUIDTarget = GUIDAt;
	ASt.dwUnk1 = 0x429DB3C7;
	ASt.dwUnk2 = 0x0155EE0F;
	ASt.fUnk1 = 1.0f;
	ASt.Zero = 0;

	tph2.m_dwSequence = ConnUser[User].move_count;
	tph2.m_wUnknown1 = 3;

	ConnUser[User].move_count++;

	for (int i=0;i<MaxUsers;i++)
	{
		if (ConnUser[i].Connected)
			Send802(&tph2, (BYTE *) &ASt, sizeof(ASt), i);
	}

}

void cACServer::SendParticle(int User, DWORD ParticleNum)
{
	cMessageHeader tph2;

	DWORD ParticleEffect[] = {
		0xF755,
		ConnUser[User].Char->GUID,
		ParticleNum,
		0
	};

	float tpf = 1.0f;
	memcpy(&ParticleEffect[3],&tpf,4);

	tph2.m_dwSequence = ConnUser[User].move_count;
	tph2.m_wUnknown1 = 3;

	ConnUser[User].move_count++;

	for (int i=0;i<MaxUsers;i++)
	{
		if (ConnUser[i].Connected)
			Send802(&tph2, (BYTE *) &ParticleEffect, sizeof(ParticleEffect), i);
	}
}

void cACServer::GiveXP(int User, int Type, DWORD Amount)
{
	cMessageHeader tph2;
	BYTE Pack237[0xD];
	DWORD tpdword;	BYTE tpbyte;

	if ((User > 128) || (!ConnUser[User].Connected) || (ConnUser[User].State != 6))
	{
		ServerMessage(User, "Error in !givexp format... Make sure you're giving a valid User #...", COLOR_RED);
		
		return;
	}

	ConnUser[User].Char->TotalXP += Amount;

	ZeroMemory(Pack237, 0xD);
	tpdword = 0x237; memcpy(&Pack237[0], &tpdword, 4);
	tpbyte = ConnUser[User].Count237[0x15];	memcpy(&Pack237[4], &tpbyte, 1);
	tpdword = 0x15;	 memcpy(&Pack237[5], &tpdword, 4);		//Total XP
	tpdword = ConnUser[User].Char->TotalXP;  memcpy(&Pack237[9], &tpdword, 4);
	tph2.m_wUnknown1 = 4;
	Send802(&tph2, Pack237, sizeof(Pack237), User);
	ConnUser[User].Count237[0x15]++;

	int NewLevel = 0;
	for (int i=0;i<128;i++)
	{
		if (ConnUser[User].Char->TotalXP < LevelArray[i])
		{
			NewLevel = i - 1;

			i = 128;
		}
	}
	if (NewLevel > ConnUser[User].Char->Level)
	{
		//Level him!
		SendParticle(User, 0x89);
		ConnUser[User].Char->Level = NewLevel;
		ConnUser[User].Char->SkillCredits++;
		
		ZeroMemory(Pack237, 0xD);
		tpdword = 0x237; memcpy(&Pack237[0], &tpdword, 4);
		tpbyte = ConnUser[User].Count237[0x19];	memcpy(&Pack237[4], &tpbyte, 1);
		tpdword = 0x19;	 memcpy(&Pack237[5], &tpdword, 4);		//Level
		tpdword = ConnUser[User].Char->Level;  memcpy(&Pack237[9], &tpdword, 4);
		tph2.m_wUnknown1 = 4;
		Send802(&tph2, Pack237, sizeof(Pack237), User);
		ConnUser[User].Count237[0x19]++;

		ZeroMemory(Pack237, 0xD);
		tpdword = 0x237; memcpy(&Pack237[0], &tpdword, 4);
		tpbyte = ConnUser[User].Count237[0x18];	memcpy(&Pack237[4], &tpbyte, 1);
		tpdword = 0x18;	 memcpy(&Pack237[5], &tpdword, 4);		//Level
		tpdword = ConnUser[User].Char->SkillCredits;  memcpy(&Pack237[9], &tpdword, 4);
		tph2.m_wUnknown1 = 4;
		Send802(&tph2, Pack237, sizeof(Pack237), User);
		ConnUser[User].Count237[0x18]++;

		sprintf(sayit, "You are now level %i!", ConnUser[User].Char->Level);
		ServerMessage(User, sayit, COLOR_CYAN);
		sprintf(sayit, "You have %u experience points and %i skill credits available to raise skills and attributes.", ConnUser[User].Char->UnassignedXP, ConnUser[User].Char->SkillCredits);
		ServerMessage(User, sayit, COLOR_CYAN);
		int NextCredit = 0, i=0;
		while (!NextCredit)
		{
			if (ConnUser[User].Char->Level < CreditLevel[i])
				NextCredit = CreditLevel[i];
			
			i++;
		}
		sprintf(sayit, "You will earn another skill credit at level %i.", NextCredit);
		ServerMessage(User, sayit, COLOR_CYAN);
	}

	if ((Type < 0) || ((Type > 39) && (Type != 128)))
	{
		ServerMessage(User, "Error in !givexp format... Type should be from 0-39 or 128 for unassigned XP...", COLOR_RED);

		return;
	}

	if (Type == SKILL_UNASSIGNED)
	{
		ConnUser[User].Char->UnassignedXP += Amount;
		
		ZeroMemory(Pack237, 0xD);
		tpdword = 0x237; memcpy(&Pack237[0], &tpdword, 4);
		tpbyte = ConnUser[User].Count237[0x16];	memcpy(&Pack237[4], &tpbyte, 1);
		tpdword = 0x16;	 memcpy(&Pack237[5], &tpdword, 4);		//Unassigned XP
		tpdword = ConnUser[User].Char->UnassignedXP;  memcpy(&Pack237[9], &tpdword, 4);
		tph2.m_wUnknown1 = 4;
		Send802(&tph2, Pack237, sizeof(Pack237), User);
		ConnUser[User].Count237[0x16]++;
	} else if (Type < 40) {
		ConnUser[User].Char->SkillXP[Type] += Amount;

		int NewSkillLevel = 0;
		for (int i=0;i<200;i++)
		{
			if (ConnUser[User].Char->SkillXP[Type] < SkillArray[i])
			{
				NewSkillLevel = i - 1;

				i = 200;
			}
		}
		if (NewSkillLevel > ConnUser[User].Char->SkillInc[Type])
		{
			ConnUser[User].Char->SkillInc[Type] = NewSkillLevel;
		}
	}
}

void cACServer::ActionComplete(int User)
{
	cMessageHeader tph2;
	DWORD ActComp[] = {
		0x0000F7B0,
		ConnUser[User].Char->GUID,
		ConnUser[User].EventCount,
		0x000001C7,
		0x00000000
	};
	ConnUser[User].EventCount++;
	tph2.m_wUnknown1 = 3;
	Send802(&tph2, (BYTE *) ActComp, sizeof(ActComp), User);
}

float GetDistance(Location_t *loc1, Location_t *loc2)
{
	DWORD landblock;
	int XX, ns, ew;
	double xc, yc, PosNSa, PosEWa, PosNSb, PosEWb;

	float Distance;

	if ((loc1->landblock & 0x0000FF00) && (loc2->landblock & 0x0000FF00))
	{
		//Interior
		Distance = fabs(sqrt(pow(loc2->x - loc1->x,2) + pow(loc2->y - loc1->y,2) +  + pow(loc2->z - loc1->z,2)))/240;
	} else {
		//Exterior
		landblock = loc1->landblock;
		xc = loc1->x;
		yc = loc1->y;

		XX = landblock & 0x3F; 
		ns = ((((landblock & 0x00FF0000) >> 16) + 1) * 8) + ((XX - 1) & 7) - 1027;
		ew = ((((landblock & 0xFF000000) >> 24) + 1) * 8) + (int) ((XX - 1) / 8) - 1027;
    
		xc = xc - ((int) (xc / 24.0f) * 24.0f);
		yc = yc - ((int) (yc / 24.0f) * 24.0f);
		PosEWa = ((float) (ew) / 10.0f) + (xc / 240.0f);
		PosNSa = ((float) (ns) / 10.0f) + (yc / 240.0f);
		
		landblock = loc2->landblock;
		xc = loc2->x;
		yc = loc2->y;

		XX = landblock & 0x3F; 
		ns = ((((landblock & 0x00FF0000) >> 16) + 1) * 8) + ((XX - 1) & 7) - 1027;
		ew = ((((landblock & 0xFF000000) >> 24) + 1) * 8) + (int) ((XX - 1) / 8) - 1027;

		xc = xc - (float) ((int) (xc / 24.0f) * 24.0f);
		yc = yc - (float) ((int) (yc / 24.0f) * 24.0f);
		PosEWb = ((float) (ew) / 10.0f) + (xc / 240.0f);
		PosNSb = ((float) (ns) / 10.0f) + (yc / 240.0f);

		Distance = fabs(sqrt(pow(PosNSa - PosNSb,2) + pow(PosEWa - PosEWb,2) + pow((loc1->z - loc2->z)/240,2)));
	}

	return(Distance);
}

void cACServer::WorldServerParse(int UserParsing, BYTE *tPackPtr, int amountRead, cClientPacketHeader *tphdr)
{
	cMessageHeader tph2;

	if (tphdr->m_dwFlags == 0x00000802) {
		cMessageHeader tpmhdr;
		DWORD MType, MType2;
		BYTE * tPackPtr;
		tPackPtr = &TestBuf[sizeof(cClientPacketHeader)];
		while (tPackPtr < &TestBuf[amountRead])
		{
			if (!ConnUser[UserParsing].Char)
				return;
			
			memcpy(&tpmhdr, tPackPtr, sizeof(tpmhdr));
			tPackPtr += sizeof(cMessageHeader);

			memcpy(&MType,tPackPtr,4);
			memcpy(&MType2,&tPackPtr[8],4);

			if (MType == 0x0000F653) {
				//Exit world..
//				DisconnectUser(UserParsing);

				SaveCharacter(UserParsing);

				LBObjects[ConnUser[UserParsing].Char->Loc.landblock >> 16].erase(ConnUser[UserParsing].Char->GUID);

				ObjectList.erase(ConnUser[UserParsing].Char->GUID);

				//Return him to char select screen
				cMessageHeader tph2;
				tph2.m_dwSequence = 0x081A9900;
				tph2.m_wUnknown1 = 0x0004;

				DWORD tph3 = 0x0000F653;

				Send802(&tph2, (BYTE *) &tph3, sizeof(tph3), UserParsing);

				//Disconnect Him
				sprintf(sayit, "Player %s Disconnected!", ConnUser[UserParsing].Char->Name);
				ServerMessage(GLOBAL_MESSAGE, sayit, COLOR_GREEN);

				//Delete him from other people
				tph2.m_dwSequence = 0;
				tph2.m_wUnknown1 = 0x0004;
				memcpy(&DESTROY_ENTITY[4],&ConnUser[UserParsing].Char->GUID,4);
				for (int iii=0;iii<MaxUsers;iii++)
				{
					if ((ConnUser[iii].Connected) && (ConnUser[iii].State == 6) && (iii != UserParsing))
						Send802(&tph2, &DESTROY_ENTITY[0], sizeof(DESTROY_ENTITY), iii);
				}

				ConnUser[UserParsing].Char = 0;

				ConnUser[UserParsing].State = 1;
			} else if (MType == 0xF6EA) {
				//Nobody knows...
			} else if (MType == 0xF7A9) {
				//Client needs landblock
				
				ServerMessage(UserParsing, "* You don't have at least one of the landblocks in your new area.  !telemap to another location or try typing /render radius 5.", COLOR_RED);
			} else if (MType == 0xF7B1) {
				if (MType2 == 0xF753)
				{
					//High-Priority Movement Packet

					Location_t *loc = (Location_t *) &tPackPtr[12];

					MoveUser(UserParsing, loc, false, false);
				} else if (MType2 == 0xF61C) {
					//Low-Priority Movement Packet

					DWORD *hex=(DWORD *)tPackPtr;

					Location_t *loc;	DWORD skip = 0;
					DWORD hex3;
					for (hex3=hex[3];hex3>0;hex3>>=1)
					{	if (hex3 & 1) skip++;	}

					//Flags
					DWORD SpeedFlag = 0, TurnFlag = 0, SlideFlag = 0, MoveFlag = 0, EmoteFlag = 0;

					DWORD * hexat = &hex[4];
					cAnimStruct ASt;
					ASt.wAnimation_Family = 0x3D;
					ASt.wAnimation_to_Play = 0x0;
					ASt.fPlaySpeed = 1.0f;
					if (hex[3] & 0x00000001)
					{	//Normal Speed, Unset = Walking
						SpeedFlag = *hexat;
						hexat += 1; }
					if (hex[3] & 0x00000004)
					{	//Moving
						DWORD MoveFlag = *hexat;
						hexat += 1;

						if (MoveFlag == 0x45000005)
						{
							ASt.fPlaySpeed = 1.0f;
							if (SpeedFlag == 0)
								ASt.wAnimation_to_Play = 0x05;
							else if (SpeedFlag == 2)
								ASt.wAnimation_to_Play = 0x07;
						} else if (MoveFlag == 0x45000006) {
							ASt.fPlaySpeed = -1.0f;
							ASt.wAnimation_to_Play = 0x05;
						} else if ((MoveFlag & 0xFF000000) == 0x41000000) {
							ASt.wAnimation_to_Play = (WORD) (MoveFlag & 0xFF);
						} else if ((MoveFlag & 0xFF000000) == 0x43000000) {
							ASt.wAnimation_to_Play = (WORD) (MoveFlag & 0xFF);
						} else {
							sprintf(sayit, "MoveFlag: %08X", MoveFlag); LogDisp(sayit);
						}
					}
					if (hex[3] & 0x00000020)
					{	//Sliding
						DWORD SlideFlag = *hexat;
						hexat += 1;

						if (SlideFlag == 0x6500000F)
						{
							ASt.fPlaySpeed = 1.0f;
							ASt.wAnimation_to_Play = 0x0F;
						} else if (SlideFlag == 0x65000010) {
							ASt.fPlaySpeed = -1.0f;
							ASt.wAnimation_to_Play = 0x0F;
						}
					}
					if (hex[3] & 0x00000100)
					{	//Turning
						DWORD TurnFlag = *hexat;
						hexat += 1;
						
						if (TurnFlag == 0x6500000D)			//Right
						{
							ASt.fPlaySpeed = 1.0f;
							ASt.wAnimation_to_Play = 0x0D;
						} else if (TurnFlag == 0x6500000E) {	//Left
							ASt.fPlaySpeed = -1.0f;
							ASt.wAnimation_to_Play = 0x0D;
						}
					}
					if (hex[3] & 0x0000F800)
					{	//Emote Backlog
						DWORD EmoteFlag = *hexat;
						DWORD numEmotes = (hex[3] & 0x0000F800) >> 11;
						hexat += (numEmotes * 2);
						skip += (numEmotes * 2) - 1;
						if (numEmotes > 2)	//For some reason, on 3+ emotes, it has another DWORD at the end
							skip++;
						
						//Just play the first one
						ASt.wAnimation_to_Play = (WORD) (EmoteFlag & 0xFF);
						if (numEmotes > 1)
						{
							//Lots of emotes...  Learn how to chain later! =]
						}
					}

					loc=(Location_t *)&hex[4+skip];
					MoveUser(UserParsing, loc, false, false);

					//Make Anim Packet... Ho ho ho!
					ASt.dwf74c = 0x0000F74C;
					ASt.dwGUID = ConnUser[UserParsing].Char->GUID;
					ASt.wNumInteractions = ConnUser[UserParsing].move_count;
					ASt.wNumLogins = ConnUser[UserParsing].Char->NumLogins;

					ConnUser[UserParsing].AnimCount++;
					ASt.wNumAnimations = ConnUser[UserParsing].AnimCount;
					ASt.wAnimation_Seqnum = ConnUser[UserParsing].AnimCount;

					ASt.wFlag = 0;
					ASt.wUnk1 = 0;
					ASt.GUIDTarget = 0x00000080;

					tph2.m_dwSequence = ConnUser[UserParsing].move_count;
					tph2.m_wUnknown1 = 3;

					for (int iii=0;iii<MaxUsers;iii++)
					{
						if ((ConnUser[iii].Connected) && (ConnUser[iii].State == 6) && (iii != UserParsing))
							Send802(&tph2, (BYTE *) &ASt, sizeof(ASt), iii);
					}

					tph2.m_dwSequence = ConnUser[UserParsing].move_count;
					cAnimStruct AStA;
					memcpy(&AStA, &ASt, sizeof(AStA));
					AStA.wFlag = 1;
					AStA.fPlaySpeed = ASt.fPlaySpeed;
					Send802(&tph2, (BYTE *) &AStA, sizeof(AStA), UserParsing);

					ConnUser[UserParsing].move_count++;
				} else if (MType2 == 0x08) {
					//Player Attacked
					DWORD PlayerAttacked; memcpy(&PlayerAttacked, &tPackPtr[12], 4);
					DWORD AttackSpot; memcpy(&AttackSpot, &tPackPtr[16], 4);
					DWORD Slider; memcpy(&Slider, &tPackPtr[20], 4);
					
					//Spot: Low/mid/high, 3/2/1

					cWorldObject_Char *tpc = (cWorldObject_Char *) ObjectList[PlayerAttacked];
					DWORD TotalSkill = ConnUser[UserParsing].Char->SkillInc[0x0D] + (ConnUser[UserParsing].Char->CurrentStat[0] + ConnUser[UserParsing].Char->CurrentStat[2])/3;
					DWORD DamageDone = (rand() & 3) + (TotalSkill / 10) + (ConnUser[UserParsing].Char->CurrentStat[0]/20);
					
					tpc->CurrentSecondaryStat[0] -= DamageDone;

					//Damage Packet

					//Recieve
					BYTE DamagePacket[100], *PackPointer = DamagePacket;

					DWORD head = 0x1b2; memcpy(PackPointer, &head, 4); PackPointer += 4;
					int strlen; GenString(ConnUser[UserParsing].Char->Name, &strlen, PackPointer);	PackPointer += strlen;

					DWORD damage = 4; memcpy(PackPointer, &damage, 4); PackPointer += 4;
					double severity = 0.5f; memcpy(PackPointer, &severity, 8); PackPointer += 8;
								memcpy(PackPointer, &DamageDone, 4); PackPointer += 4;
					tph2.m_wUnknown1 = 4;
					Send802(&tph2, DamagePacket, (DWORD) PackPointer - (DWORD) DamagePacket, tpc->Owner);
					
					//Inflict
					PackPointer = DamagePacket;

					head = 0x1b1; memcpy(PackPointer, &head, 4); PackPointer += 4;
					GenString(tpc->Name, &strlen, PackPointer);	PackPointer += strlen;

					memcpy(PackPointer, &damage, 4); PackPointer += 4;
					memcpy(PackPointer, &severity, 8); PackPointer += 8;
								memcpy(PackPointer, &DamageDone, 4); PackPointer += 4;
					DWORD spot;
					switch (AttackSpot)
					{
					case 1:
						//High
						spot = rand() & 1;
						break;
					case 2:
						//Mid
						spot = 1 + (rand() % 5);
						break;
					case 3:
						//Low
						spot = 7 + (rand() & 1);
						break;
					}
									memcpy(PackPointer, &spot, 4); PackPointer += 4;

					Send802(&tph2, DamagePacket, (DWORD) PackPointer - (DWORD) DamagePacket - 4, UserParsing);

					//Attack Completed
					DWORD tp1a7[] = {
						0x0000F7B0,
						ConnUser[UserParsing].Char->GUID,
						ConnUser[UserParsing].EventCount,
						0x01A7,
						ConnUser[UserParsing].AttackCount
					};
					Send802(&tph2, (BYTE *) tp1a7, sizeof(tp1a7), UserParsing);
					ConnUser[UserParsing].AttackCount++;
					ConnUser[UserParsing].EventCount++;

					if ((int) tpc->CurrentSecondaryStat[0] <= 0)
					{
						//Dead ktnxunf
						sprintf(sayit, "%s was 0wn3d by %s!", tpc->Name, ConnUser[UserParsing].Char->Name);
						ServerMessage(GLOBAL_MESSAGE, sayit, COLOR_GREEN);

						tpc->CurrentSecondaryStat[0] = (tpc->CurrentStat[1]/2) + tpc->SecondaryStatInc[0];

						MoveUser(tpc->Owner, &tpc->LSTie, true, false);
					}
				} else if (MType2 == 0x36) {
					//Player used item
					DWORD tpguid; memcpy(&tpguid, &tPackPtr[12], 4);
					cWorldObject * tpitem = ObjectList[tpguid];
					switch (tpitem->Type)
					{
					case OBJECT_LIFESTONE:
						memcpy(&ConnUser[UserParsing].Char->LSTie, &ConnUser[UserParsing].Char->Loc, sizeof(Location_t));
						ServerMessage(UserParsing, "You successfully tie to the lifestone!", COLOR_BLUE);
						SendAnim(UserParsing, 0x0036);
						break;
					case OBJECT_PORTAL:
						PointAt(UserParsing, tpguid);
//									SendAnim(UserParsing, 7);	//Run
//									ActionComplete(UserParsing);
						break;
					}
				} else if (MType2 == 0x63) {
					//Player /lifestoned :)
					sprintf(sayit, "%s died!", ConnUser[UserParsing].Char->Name);
					ServerMessage(GLOBAL_MESSAGE, sayit, COLOR_GREEN);

//								SendAnim(UserParsing, 0x0008);
					
					MoveUser(UserParsing, &ConnUser[UserParsing].Char->LSTie, true, false);
				} else if (MType2 == 0xA1) {
					//Character logged in...
					
					UpdateCharInfo(UserParsing, "Fully Logged In");

					//Fully log him in on others
					tph2.m_wUnknown1 = 3;
					tph2.m_dwSequence = 1;
					DWORD F74B[] = {
						0x0000F74B,
						ConnUser[UserParsing].Char->GUID,
						0x00400410,
						0x00020003
					};
//					memcpy(&F74B[3], &ConnUser[UserParsing].Char->NumLogins, 2);
//					memcpy((&F74B[3]) + 2, &ConnUser[UserParsing].PortalCount, 2);

					for (int iii=0;iii<MaxUsers;iii++)
					{
						if ((ConnUser[iii].Connected) && (ConnUser[iii].State == 6))
							Send802(&tph2, (BYTE *) F74B, sizeof(F74B), iii);
					}
					
					tph2.m_wUnknown1 = 3;
					tph2.m_dwSequence = 1;

					BYTE CreatePlayer[0x500];	int packlen;
					for (iii=0;iii<MaxUsers;iii++)
					{
						if ((ConnUser[iii].Connected) && (ConnUser[iii].State == 6) && (iii != UserParsing))
						{
							packlen = ConnUser[iii].Char->GenerateCreatePacket(CreatePlayer);
							//Show others on him
							Send802(&tph2, CreatePlayer, packlen, UserParsing);

							memcpy(&F74B[1], &ConnUser[iii].Char->GUID, 4);
							Send802(&tph2, (BYTE *) &F74B[0], sizeof(F74B), UserParsing);
						}
					}
				} else if (MType2 == 0x00000015) {
					//Text Message from Client
					if ((int) (tpmhdr.m_wFragmentLength-14-sizeof(cMessageHeader)) > 0)
					{
						char messagetext[2000];
						memcpy(messagetext,&tPackPtr[14],tpmhdr.m_wFragmentLength-14-sizeof(cMessageHeader));

						if (*messagetext == '!')
						{
							//Command
							char command[50], *Contents; ZeroMemory(command, 50);
//										char seps[] = " ";
							if (strstr(messagetext, " "))
							{
								memcpy(command,messagetext,(DWORD) strstr(messagetext, " ") - (DWORD) messagetext);
								Contents = strstr(messagetext," ");
							} else {
								memcpy(command,messagetext,strlen(messagetext));
								Contents = 0;
							}
							if (Contents)
								Contents = strstr(Contents, " ") + 1;
							
							int NumParms = 0;
							char Parms[10][20];	ZeroMemory(Parms, 10*20);
							if ((DWORD) Contents > 1)
							{
								char *tp = /*strstr(Contents," ") + 1*/ Contents, *tp2;
								while ((DWORD) tp > 1)
								{
									tp2 = strstr(tp," ") + 1;
									if ((DWORD) tp2 <= 1)
									{
										memcpy(Parms[NumParms], tp, strlen(tp));
										NumParms++;
										tp = tp2;
									} else {
										memcpy(Parms[NumParms], tp, (DWORD) (tp2 - tp - 1));
										NumParms++;
										tp = tp2;
									}
								}
							}

							if (stricmp(&command[1],"tele") == 0)	//Teleport by landblock
							{
								try {
									Location_t templ;
									memcpy(&templ, &ConnUser[UserParsing].Char->Loc, sizeof(Location_t));

									if (NumParms < 4)
									{
										ServerMessage(UserParsing, "Error in !tele syntax, check !help!", COLOR_RED);
										return;
									}
									//Fill in new Loc...
									sscanf(Parms[0],"%f",&templ.x);
									sscanf(Parms[1],"%f",&templ.y);
									sscanf(Parms[2],"%f",&templ.z);
									sscanf(Parms[3],"%08X",&templ.landblock);

									MoveUser(UserParsing, &templ, true, false);
								} catch (char *) {
									ServerMessage(UserParsing, "Error in !tele syntax, check !help...", COLOR_RED);
									return;
								}
							} else if (stricmp(&command[1],"telemap") == 0) {
								try {
									if (NumParms < 2)
									{
										ServerMessage(UserParsing, "Error in !telemap syntax, check !help!", COLOR_RED);
										return;
									}
									float NS, EW;//, Nx, Ny;
									char tpt;
									tpt = Parms[0][strlen(Parms[0])-1];
									Parms[0][strlen(Parms[0])-1] = 0;
									if ((tpt == 'N') || (tpt == 'n'))
									{
										sscanf(Parms[0],"%f",&NS);
									} else if ((tpt == 'S') || (tpt == 's')) {
										sscanf(Parms[0],"%f",&NS);
										NS *= -1;
									} else {
										NS = 0;
									}

									tpt = Parms[1][strlen(Parms[1])-1];
									Parms[1][strlen(Parms[1])-1] = 0;
									if ((tpt == 'E') || (tpt == 'e'))
									{
										sscanf(Parms[1],"%f",&EW);
									} else if ((tpt == 'W') || (tpt == 'w')) {
										sscanf(Parms[1],"%f",&EW);
										EW *= -1;
									} else {
										EW = 0;
									}

									Location_t templ;
									
									templ.x = (EW*10.0f+1020.0f)*24.0f;
									templ.y = (NS*10.0f-1020.0f)*24.0f;
									if (NumParms == 3)
										sscanf(Parms[2], "%f", &templ.z);
									else
										templ.z = 0.0f;
									
									templ.landblock = 
											( (BYTE) ((((DWORD) templ.x%192)/24)*8) + (((DWORD) templ.y%192)/24) ) |
											( (0x00) << 8) |
											( (BYTE) (templ.y/192.0f) << 16) |
											( (BYTE) (templ.x/192.0f) << 24)
										;
									templ.landblock -= 0x00010000;

									templ.x = (float) ((int) templ.x % 192);
									templ.y = (float) ((int) templ.y % 192);

									MoveUser(UserParsing, &templ, true, false);
								} catch (char *) {
									ServerMessage(UserParsing, "Error in !telemap syntax, check !help...", COLOR_RED);
									return;
								}
							} else if (stricmp(&command[1],"srvmsg") == 0) {
								try {
									sprintf(sayit, "Server Message from %s: %s", ConnUser[UserParsing].Char->Name, Contents);
									ServerMessage(GLOBAL_MESSAGE, sayit, COLOR_GREEN);
								} catch (char *) {
									ServerMessage(UserParsing, "Error in !srvmsg syntax, check !help...", COLOR_RED);
									return;
								}
							} else if (stricmp(&command[1],"who") == 0) {
								//Send list of people
								ServerMessage(UserParsing, "Listing Players:", COLOR_GREEN);
								for (int i=0;i<MaxUsers;i++)
								{
									if ((ConnUser[i].Connected) && (ConnUser[i].Char))
									{
										sprintf(sayit, "* %i - %i.%i.%i.%i:%i - %s - %s",
											i,
											ConnUser[i].sockaddy.sin_addr.S_un.S_un_b.s_b1,
											ConnUser[i].sockaddy.sin_addr.S_un.S_un_b.s_b2,
											ConnUser[i].sockaddy.sin_addr.S_un.S_un_b.s_b3,
											ConnUser[i].sockaddy.sin_addr.S_un.S_un_b.s_b4,
											ntohs(ConnUser[i].sockaddy.sin_port),
											ConnUser[i].Char->Name,
											ConnUser[i].Status);
										ServerMessage(UserParsing, sayit, COLOR_GREEN);
									}
								}
							} else if (stricmp(&command[1],"kick") == 0) {
								try {	
									DWORD tokick;
									sscanf(Contents, "%i", &tokick);
									if ((tokick < 128) && (ConnUser[tokick].Connected))
									{
										DisconnectUser(tokick);
									} else {
										//Try by name...
										for (int ii=0;ii<MaxUsers;ii++)
										{
											if (stricmp(Contents, ConnUser[ii].Char->Name) == 0)
											{	DisconnectUser(ii); break; }
										}
									}
								} catch (char *) {
									ServerMessage(UserParsing, "Error in !kick syntax, check !help...", COLOR_RED);
									return;
								}
							} else if (stricmp(&command[1],"help") == 0) {
								ServerMessage(UserParsing, "List of KillaServ Commands:", COLOR_BLUE);
								ServerMessage(UserParsing, "-=* Help/Info Commands *=-", COLOR_YELLOW);
								ServerMessage(UserParsing, "* !help - This List", COLOR_GREEN);
								ServerMessage(UserParsing, "* !who - List of Users Online (Gets Player Numbers)", COLOR_GREEN);
								ServerMessage(UserParsing, "-=* Teleporting Commands *=-", COLOR_YELLOW);
								ServerMessage(UserParsing, "* !tele [X] [Y] [Z] [Landblock] - Teleport by Location_T", COLOR_GREEN);
								ServerMessage(UserParsing, "* !telemap [xx.xN/S] [xx.xE/W] [(Z)] - Teleport by NSEW coords with optional Z", COLOR_GREEN);
								ServerMessage(UserParsing, "* !telemapother [player number] [xx.xN/S] [xx.xE/W] [(Z)] - Teleports [player number] by NSEW coords with optional Z", COLOR_GREEN);
								ServerMessage(UserParsing, "* !goto [player number] - Teleports you to [player number]", COLOR_GREEN);
								ServerMessage(UserParsing, "* !summon [player number] - Summons [player number] to you", COLOR_GREEN);
								ServerMessage(UserParsing, "-=* Fun Commands *=-", COLOR_YELLOW);
								ServerMessage(UserParsing, "* !anim [anim number (0 to FF, hex)] - Make character do animation", COLOR_GREEN);
								ServerMessage(UserParsing, "* !particle [anim number (0 to FF, hex)] - Make particle effect emanete from character", COLOR_GREEN);
								ServerMessage(UserParsing, "* !smite [player number] - Hmmm...", COLOR_GREEN);
								ServerMessage(UserParsing, "* !changemodel [new model #] - Change your character to this model #", COLOR_GREEN);
								ServerMessage(UserParsing, "-=* Server Commands *=-", COLOR_YELLOW);
								ServerMessage(UserParsing, "* !givexp [player number] [Type] [Amount] - Give player XP", COLOR_GREEN);
								ServerMessage(UserParsing, "* !srvmsg [message] - Server Message", COLOR_GREEN);
								ServerMessage(UserParsing, "* !kick [player number] - Kick player by number", COLOR_GREEN);
								ServerMessage(UserParsing, "* !reorglist - Reorg Character List", COLOR_GREEN);
								ServerMessage(UserParsing, "* !create [named item] - Create Named Item. Use '!create help' for a list of creatable objects", COLOR_GREEN);
								ServerMessage(UserParsing, "Use commands with care, no syntax checking is implemented yet.  It's easy to crash the server misusing commands...", COLOR_RED);
							} else if (stricmp(&command[1],"changemodel") == 0) {
								WORD NewModel;
								sscanf(Parms[0], "%i", &NewModel);
								ConnUser[UserParsing].Char->Model = NewModel;
								ServerMessage(UserParsing, "Model changed!  Relog to see the effect...", COLOR_RED);
							} else if (stricmp(&command[1],"givexp") == 0) {
								int PlayerFor;
								sscanf(Parms[0], "%i", &PlayerFor);
								int Type;
								sscanf(Parms[1], "%i", &Type);
								DWORD AmounttoGive;
								sscanf(Parms[2], "%u", &AmounttoGive);

								GiveXP(PlayerFor, Type, AmounttoGive);
							} else if (stricmp(&command[1],"damage") == 0) {
								BYTE DamagePacket[100], *PackPointer = DamagePacket;

								DWORD head = 0x1b2; memcpy(PackPointer, &head, 4); PackPointer += 4;
								int strlen; GenString("Someone", &strlen, PackPointer);	PackPointer += strlen;

								DWORD damage = 4; memcpy(PackPointer, &damage, 4); PackPointer += 4;
								double severity = 0.5f; memcpy(PackPointer, &severity, 8); PackPointer += 8;
								DWORD amount = rand() & 7; memcpy(PackPointer, &amount, 4); PackPointer += 4;

								tph2.m_wUnknown1 = 4;
								Send802(&tph2, DamagePacket, (DWORD) PackPointer - (DWORD) DamagePacket, UserParsing);
							
							} else if (stricmp(&command[1],"create") == 0) {
								DWORD tpguid; bool freeg = false;
								while (!freeg)
								{
									tpguid = 0x78000000 | ((rand()*rand()) & 0x00FFFFFF);
									if (ObjectList[tpguid] == 0)
										freeg = true;
								}

								if (!Contents)
								{
									ServerMessage(UserParsing, "Try !create help...", COLOR_BLUE);
									return;
								}

								if (stricmp(Contents, "help") == 0)
								{
									ServerMessage(UserParsing, "!create currently supports the following objects: lifestone, obj, portal, portalloc.", COLOR_BLUE);
									ServerMessage(UserParsing, "+-> Lifestone - Creates a lifestone in front of you", COLOR_GREEN);
									ServerMessage(UserParsing, "+-> Obj - Creates generic objects... See !create obj help", COLOR_GREEN);
									ServerMessage(UserParsing, "+-> Portal [name] [loc] - Creates portal by //loc address, [loc] is same format as !tele", COLOR_GREEN);
									ServerMessage(UserParsing, "\\-> Portalloc [name] [loc] - Creates portal by NSEW coords, [loc] is same format as !telemap", COLOR_GREEN);
								} else if (stricmp(Parms[0], "portalloc") == 0) {
									cWorldObject_Portal *tpprt = new cWorldObject_Portal();
									
									tpprt->GUID = tpguid;
									memcpy(&tpprt->Loc, &ConnUser[UserParsing].Char->Loc, sizeof(Location_t));
									tpprt->Loc.x += 5.0f*ConnUser[UserParsing].PointX;
									tpprt->Loc.y += 5.0f*ConnUser[UserParsing].PointY;

									try {
										if (NumParms < 4)
										{
											ServerMessage(UserParsing, "Error in !create portalloc syntax, check !help!", COLOR_RED);
											return;
										}
										char *usrep = strchr(Parms[1],'_');
										while (usrep)
										{
											*usrep = ' ';
											usrep = strchr(Parms[1],'_');
										}
										strcpy(tpprt->Name, Parms[1]);
										
										float NS, EW;//, Nx, Ny;
										char tpt;
										tpt = Parms[2][strlen(Parms[2])-1];
										Parms[2][strlen(Parms[2])-1] = 0;
										if ((tpt == 'N') || (tpt == 'n'))
										{
											sscanf(Parms[2],"%f",&NS);
										} else if ((tpt == 'S') || (tpt == 's')) {
											sscanf(Parms[2],"%f",&NS);
											NS *= -1;
										} else {
											NS = 0;
										}

										tpt = Parms[3][strlen(Parms[3])-1];
										Parms[3][strlen(Parms[3])-1] = 0;
										if ((tpt == 'E') || (tpt == 'e'))
										{
											sscanf(Parms[3],"%f",&EW);
										} else if ((tpt == 'W') || (tpt == 'w')) {
											sscanf(Parms[3],"%f",&EW);
											EW *= -1;
										} else {
											EW = 0;
										}

										tpprt->DestLoc.x = (EW*10.0f+1020.0f)*24.0f;
										tpprt->DestLoc.y = (NS*10.0f-1020.0f)*24.0f;
										if (NumParms == 5)
											sscanf(Parms[4], "%f", &tpprt->DestLoc.z);
										else
											tpprt->DestLoc.z = 500.0f;
										
										tpprt->DestLoc.landblock = 
												( (BYTE) ((((DWORD) tpprt->DestLoc.x%192)/24)*8) + (((DWORD) tpprt->DestLoc.y%192)/24) ) |
												( (0x00) << 8) |
												( (BYTE) (tpprt->DestLoc.y/192.0f) << 16) |
												( (BYTE) (tpprt->DestLoc.x/192.0f) << 24)
											;
										tpprt->DestLoc.landblock -= 0x00010000;

										tpprt->DestLoc.x = (float) ((int) tpprt->DestLoc.x % 192);
										tpprt->DestLoc.y = (float) ((int) tpprt->DestLoc.y % 192);
									} catch (char *) {
										ServerMessage(UserParsing, "Error in !create portalloc syntax, check !help...", COLOR_RED);
										return;
									}

									LBObjects[tpprt->Loc.landblock >> 16][tpprt->GUID] = (cWorldObject *) tpprt;
									Portals[tpprt->Loc.landblock >> 16][tpprt->GUID] = tpprt;
									ObjectList[tpguid] = (cWorldObject *) tpprt;

									BYTE TpP[500];
									tph2.m_wUnknown1 = 3;
									int packlen = tpprt->GenerateCreatePacket(TpP);
									for (int iii=0;iii<MaxUsers;iii++)
										if (ConnUser[iii].Connected)
											Send802(&tph2, TpP, packlen, iii);
								} else if (stricmp(Parms[0], "portal") == 0) {
									cWorldObject_Portal *tpprt = new cWorldObject_Portal();
									
									tpprt->GUID = tpguid;
									memcpy(&tpprt->Loc, &ConnUser[UserParsing].Char->Loc, sizeof(Location_t));
									tpprt->Loc.x += 3.0f;

									try {
										if (NumParms < 6)
										{
											ServerMessage(UserParsing, "Error in !create portal syntax, check !help!", COLOR_RED);
											return;
										}
										char *usrep = strchr(Parms[1],'_');
										while (usrep)
										{
											*usrep = ' ';
											usrep = strchr(Parms[1],'_');
										}
										strcpy(tpprt->Name, Parms[1]);
										sscanf(Parms[2],"%f",&tpprt->DestLoc.x);
										sscanf(Parms[3],"%f",&tpprt->DestLoc.y);
										sscanf(Parms[4],"%f",&tpprt->DestLoc.z);
										sscanf(Parms[5],"%08X",&tpprt->DestLoc.landblock);
									} catch (char *) {
										ServerMessage(UserParsing, "Error in !create portal syntax, check !help...", COLOR_RED);
										return;
									}

									LBObjects[tpprt->Loc.landblock >> 16][tpprt->GUID] = (cWorldObject *) tpprt;
									Portals[tpprt->Loc.landblock >> 16][tpprt->GUID] = tpprt;
									ObjectList[tpguid] = (cWorldObject *) tpprt;

									BYTE TpP[500];
									tph2.m_wUnknown1 = 3;
									int packlen = tpprt->GenerateCreatePacket(TpP);
									for (int iii=0;iii<MaxUsers;iii++)
										if (ConnUser[iii].Connected)
											Send802(&tph2, TpP, packlen, iii);
								} else if (stricmp(Parms[0], "lifestone") == 0) {
									cWorldObject_LS *tpls = new cWorldObject_LS();
									
									tpls->GUID = tpguid;
									tpls->Type = OBJECT_LIFESTONE;
									memcpy(&tpls->Loc, &ConnUser[UserParsing].Char->Loc, sizeof(Location_t));
									tpls->Loc.x += 1.0f;

									LBObjects[tpls->Loc.landblock >> 16][tpls->GUID] = (cWorldObject *) tpls;
									ObjectList[tpguid] = (cWorldObject *) tpls;

									BYTE TpP[500];
									tph2.m_wUnknown1 = 3;
									int packlen = tpls->GenerateCreatePacket(TpP);
									for (int iii=0;iii<MaxUsers;iii++)
										if (ConnUser[iii].Connected)
										Send802(&tph2, TpP, packlen, iii);
								} else if (stricmp(Parms[0], "obj") == 0) {
									if (stricmp(Parms[1], "help") == 0)
									{
										ServerMessage(UserParsing, "Syntax: !create obj -id ** [-name **] [-selectable]", COLOR_RED);
										ServerMessage(UserParsing, "+-> -id *** - Gives the object a Model # of **", COLOR_RED);
										ServerMessage(UserParsing, "+-> -name *** - Names the object this", COLOR_RED);
										ServerMessage(UserParsing, "\\-> -selectable - Makes the object selectable", COLOR_RED);
										return;
									}

									cWorldObject_ObjectID *tpObj = new cWorldObject_ObjectID();

									tpObj->Flags = 0;
									sprintf(tpObj->Name, "Unnamed Object");
									tpObj->Model = 1;

									try {
										int CurParm = 1;

										while (CurParm < NumParms)
										{
											if (stricmp(Parms[CurParm],"-id") == 0)
											{
												sscanf(Parms[CurParm+1], "%i", &tpObj->Model);
												CurParm++;
											}
											else if (stricmp(Parms[CurParm],"-selectable") == 0)
											{
												tpObj->Flags |= BYOBJ_SELECTABLE;
											}
											else if (stricmp(Parms[CurParm],"-name") == 0)
											{
												sscanf(Parms[CurParm+1], "%s", &tpObj->Name);
												CurParm++;
											}
											CurParm++;
										}
									} catch (...) {
										sprintf(sayit, "Error, check syntax: %s", messagetext);
										ServerMessage(UserParsing, sayit, COLOR_RED);
									}

									sprintf(sayit, "Model Created with ID: %i", tpObj->Model);
									ServerMessage(UserParsing, sayit, COLOR_RED);

									tpObj->GUID = tpguid;
									tpObj->Type = OBJECT_OBJECTID;
									memcpy(&tpObj->Loc, &ConnUser[UserParsing].Char->Loc, sizeof(Location_t));
									tpObj->Loc.x += 5.0f*ConnUser[UserParsing].PointX;
									tpObj->Loc.y += 5.0f*ConnUser[UserParsing].PointY;

									LBObjects[tpObj->Loc.landblock >> 16][tpObj->GUID] = (cWorldObject *) tpObj;
									ObjectList[tpguid] = (cWorldObject *) tpObj;

									BYTE TpP[500];
									tph2.m_wUnknown1 = 3;
									int packlen = tpObj->GenerateCreatePacket(TpP);
									for (int iii=0;iii<MaxUsers;iii++)
										if (ConnUser[iii].Connected)
											Send802(&tph2, TpP, packlen, iii);
								}
							} else if (stricmp(&command[1],"renamesel") == 0) {
								DWORD GUIDtoChange = ConnUser[UserParsing].SelectedItem;
								cWorldObject *newobj = ObjectList[GUIDtoChange];
								if (newobj)
								{
									sprintf(newobj->Name, "%s", Parms[0]);
									sprintf(sayit, "Object %08X renamed to %s!", GUIDtoChange, newobj->Name);
									ServerMessage(UserParsing, sayit, COLOR_BLUE);
								}
							} else if (stricmp(&command[1],"renameobject") == 0) {
								DWORD GUIDtoChange; sscanf(Parms[0], "%08x", &GUIDtoChange);
								cWorldObject *newobj = ObjectList[GUIDtoChange];
								if (newobj)
								{
									sprintf(newobj->Name, "%s", Parms[1]);
									sprintf(sayit, "Object %08X renamed to %s!", GUIDtoChange, newobj->Name);
									ServerMessage(UserParsing, sayit, COLOR_BLUE);
								}
							} else if (stricmp(&command[1],"listobjects") == 0) {
								ServerMessage(UserParsing, "Listing Objects in Current Landblock...", COLOR_BLUE);
								for (std::map<DWORD, cWorldObject *>::iterator i = LBObjects[ConnUser[UserParsing].Char->Loc.landblock >> 16].begin(); i != LBObjects[ConnUser[UserParsing].Char->Loc.landblock >> 16].end(); i++)
								{
									if ((i->second->Type) && (i->second->GUID != ConnUser[UserParsing].Char->GUID))
									{
										sprintf(sayit, "Object: %08X, Type: %i, Name: %s", i->second->GUID, i->second->Type, i->second->Name);
										ServerMessage(UserParsing, sayit, COLOR_BLUE);
									}
								}
								ServerMessage(UserParsing, "End of list!", COLOR_BLUE);
							} else if (stricmp(&command[1],"anim") == 0) {
								try {
									DWORD tpdw;
									sscanf(Contents, "%04X",  &tpdw);
									
									SendAnim(UserParsing, tpdw);
								} catch (char *) {
									ServerMessage(UserParsing, "Error in !anim syntax, check !help...", COLOR_RED);
									return;
								}
							} else if (stricmp(&command[1],"particle") == 0) {
								try {
									DWORD tpdw;
									sscanf(Contents,"%02x",&tpdw);

									SendParticle(UserParsing, tpdw);
								} catch (char *) {
									ServerMessage(UserParsing, "Error in !particle syntax, check !help...", COLOR_RED);
									return;
								}
							} else if (stricmp(&command[1],"smite") == 0) {
								try {
									DWORD Playertokill;
									sscanf(Contents, "%04X",  &Playertokill);
									if (Playertokill > (DWORD) MaxUsers)
										return;

									SendAnim(Playertokill, 0x08);

									sprintf(sayit, "%s smites %s!", ConnUser[UserParsing].Char->Name, ConnUser[Playertokill].Char->Name);
									ServerMessage(GLOBAL_MESSAGE, sayit, COLOR_GREEN);
								} catch (char *) {
									ServerMessage(UserParsing, "Error in !smite syntax, check !help...", COLOR_RED);
									return;
								}
							} else if (stricmp(&command[1],"summon") == 0) {
								DWORD ToAssist;
								try {
									sscanf(Contents, "%i", &ToAssist);
									
									MoveUser(ToAssist, &ConnUser[UserParsing].Char->Loc, true, false);
								} catch (char *) {
									ServerMessage(UserParsing, "Error in !summon syntax, check !help...", COLOR_RED);
									return;
								}
							} else if (stricmp(&command[1],"goto") == 0) {
								DWORD ToGoto;
								try {
									sscanf(Contents, "%i", &ToGoto);
									
									MoveUser(UserParsing, &ConnUser[ToGoto].Char->Loc, true, false);
								} catch (char *) {
									ServerMessage(UserParsing, "Error in !goto syntax, check !help...", COLOR_RED);
									return;
								}
							} else if (stricmp(&command[1],"telemapother") == 0) {
								try {
									if (NumParms < 3)
									{
										ServerMessage(UserParsing, "Error in !telemap syntax, check !help!", COLOR_RED);
										return;
									}

									DWORD Chartotele;
									sscanf(Parms[0],"%i",&Chartotele);
									
									float NS, EW;//, Nx, Ny;
									char tpt;
									tpt = Parms[0][strlen(Parms[1])-1];
									Parms[1][strlen(Parms[1])-1] = 0;
									if ((tpt == 'N') || (tpt == 'n'))
									{
										sscanf(Parms[1],"%f",&NS);
									} else if ((tpt == 'S') || (tpt == 's')) {
										sscanf(Parms[1],"%f",&NS);
										NS *= -1;
									} else {
										NS = 0;
									}

									tpt = Parms[2][strlen(Parms[2])-1];
									Parms[2][strlen(Parms[2])-1] = 0;
									if ((tpt == 'E') || (tpt == 'e'))
									{
										sscanf(Parms[2],"%f",&EW);
									} else if ((tpt == 'W') || (tpt == 'w')) {
										sscanf(Parms[2],"%f",&EW);
										EW *= -1;
									} else {
										EW = 0;
									}

									Location_t templ;
									
									templ.x = (EW*10.0f+1020.0f)*24.0f;
									templ.y = (NS*10.0f-1020.0f)*24.0f;
									if (NumParms == 4)
										sscanf(Parms[3], "%f", &templ.z);
									else
										templ.z = 500.0f;

									templ.landblock = 
											( (BYTE) ((((DWORD) templ.x%192)/24)*8) + (((DWORD) templ.y%192)/24) ) |
											( (0x00) << 8) |
											( (BYTE) (templ.y/192.0f) << 16) |
											( (BYTE) (templ.x/192.0f) << 24)
										;
									templ.landblock -= 0x00010000;

									templ.x = (float) ((int) templ.x % 192);
									templ.y = (float) ((int) templ.y % 192);

									MoveUser(Chartotele, &templ, true, false);
								} catch (char *) {
									ServerMessage(UserParsing, "Error in !telemapother syntax, check !help...", COLOR_RED);
									return;
								}
							} else if (stricmp(&command[1],"reorglist") == 0) {
								ServerMessage(GLOBAL_MESSAGE, "* Server List Reorganize Started... Server May lag everyone off.", COLOR_RED);

								time_t starttime = time(NULL);
								ReorgCharFile();
								int timelen = (starttime - time(NULL));

								sprintf(sayit, "* Server List Reorganize Finished!  Took %i seconds...", timelen);
								ServerMessage(GLOBAL_MESSAGE, sayit, COLOR_RED);
							}
						} else {
							//Actual text message... omgomgmog
							tph2.m_dwSequence = 0x081A9900;
							tph2.m_wUnknown1 = 0x0004;

							BYTE tpmessage[0x1000];	ZeroMemory(tpmessage, sizeof(tpmessage));
							BYTE * PacketPointer = &tpmessage[0];
								
							int tplen;
							DWORD tpn = 0x00000037; memcpy(PacketPointer, &tpn, 4); PacketPointer += 4;
							GenString(messagetext, &tplen, PacketPointer);	PacketPointer += tplen;
							GenString(&ConnUser[UserParsing].Char->Name[0], &tplen, PacketPointer);	PacketPointer += tplen;
												memcpy(PacketPointer, &ConnUser[UserParsing].Char->GUID, 4); PacketPointer += 4;
							tpn = 0x2;			memcpy(PacketPointer, &tpn, 4); PacketPointer += 4;
							
							for (int iii=0;iii<MaxUsers;iii++)
							{
								if ((ConnUser[iii].Connected) && (ConnUser[iii].State == 6))
									Send802(&tph2, &tpmessage[0], (int) (PacketPointer - &tpmessage[0]), iii);
							}
						}

//									delete [] messagetext;
					}
				} else if (MType2 == 0x01DF) {
					//Emote!
					char *messagetext = new char[tpmhdr.m_wFragmentLength-14-sizeof(cMessageHeader)];
					memcpy(messagetext,&tPackPtr[14],tpmhdr.m_wFragmentLength-14-sizeof(cMessageHeader));

					tph2.m_dwSequence = ConnUser[UserParsing].msgID;
					tph2.m_wUnknown1 = 0x0004;

					BYTE tpmessage[0x1000];	ZeroMemory(tpmessage, sizeof(tpmessage));
					BYTE * PacketPointer = &tpmessage[0];
						
					int tplen;
					DWORD tpn = 0x000001E2;
					memcpy(PacketPointer, &tpn, 4); PacketPointer += 4;
					memcpy(PacketPointer, &ConnUser[UserParsing].Char->GUID, 4); PacketPointer += 4;
					GenString(&ConnUser[UserParsing].Char->Name[0], &tplen, PacketPointer);	PacketPointer += tplen;
					GenString(messagetext, &tplen, PacketPointer);	PacketPointer += tplen;

					for (int iii=0;iii<MaxUsers;iii++)
					{
						if ((ConnUser[iii].Connected) && (ConnUser[iii].State == 6))
							Send802(&tph2, &tpmessage[0], (int) (PacketPointer - &tpmessage[0]), iii);
					}
				} else if (MType2 == 0x01E1) {
					//Emote Text...
					char MsgText[100];
					sprintf(MsgText, "%s %s", ConnUser[UserParsing].Char->Name, &tPackPtr[14]);

					ServerMessage(-1*(UserParsing+1), &MsgText[0], COLOR_GREY);
				} else if (MType2 == 0x53) {
					//Toggle Combat Mode
					//4th dword: 1 = peace, 2 = war
					
					DWORD CombatMode; memcpy(&CombatMode, &tPackPtr[12], 4);
					if (CombatMode == 1)
					{
						SendAnim(UserParsing, 0x3b);
					} else {
						if (ConnUser[UserParsing].Char->Equipped[EQUIPPED_WEAPON] == 0)
						{
							//Punching
							SendAnim(UserParsing, 0x3c);
						} else {
//										cWorldObject_Weapon *WeaponUsing = (cWorldObject_Weapon *) ConnUser[UserParsing].ObjectCache[ConnUser[UserParsing].Char->Equipped[EQUIPPED_WEAPON]];
//										if (!WeaponUsing)
//											WeaponUsing = (cWorldObject_Weapon *) ObjectList[ConnUser[UserParsing].Char->Equipped[EQUIPPED_WEAPON]];
						}
					}
				} else if (MType2 == 0xC8) {
					//Eval
					//4th dword = GUID to eval

					DWORD dwEvalGUID; memcpy(&dwEvalGUID, &tPackPtr[12], 4);

					EvalObject(UserParsing, dwEvalGUID);

					ActionComplete(UserParsing);
				} else if (MType2 == 0x19) {
					//Move Item
					//4th dword = GUID to move
					//5th dword = GUID of item to move it into... Player for equipping, bag for putting it in.
					//6th dword = Index in item to put it in

					DWORD GUIDMove;
					memcpy(&GUIDMove, &tPackPtr[12],4);

					DWORD Pack22[] = {
						0x00000022,
						GUIDMove
					};
					tph2.m_wUnknown1 = 4;
					Send802(&tph2, (BYTE *) &Pack22[0], sizeof(Pack22), UserParsing);

					if (GUIDMove == ConnUser[UserParsing].Char->Equipped[EQUIPPED_WEAPON])
					{
						//F7B0/22
						DWORD MoveItemArr[] = {
							0x0000F7B0,
							ConnUser[UserParsing].Char->GUID,
							ConnUser[UserParsing].EventCount,
							0x00000022,
							0,
							0,
							0
						};
						memcpy(&MoveItemArr[4],&tPackPtr[12],3*4);
						tph2.m_wUnknown1 = 4;
						tph2.m_dwSequence = ConnUser[UserParsing].msgID;
						ConnUser[UserParsing].EventCount++;
						Send802(&tph2, (BYTE *) &MoveItemArr[0], sizeof(MoveItemArr), UserParsing);
						
						//First 22D
						BYTE Pack22D[0x15]; ZeroMemory(Pack22D, 0x15);
						DWORD tpdword;	BYTE tpbyte;
						tpdword = 0x22D; memcpy(&Pack22D[0], &tpdword, 4);		//22D = set wielder/container
						tpbyte = ConnUser[UserParsing].EquipCount;	memcpy(&Pack22D[4], &tpbyte, 1);	//EquipCount
						//byte here...
										 memcpy(&Pack22D[5], &GUIDMove, 4);		//Item
						tpdword = 3;     memcpy(&Pack22D[9], &tpdword, 4);		//Set Wielder
						tpdword = 0;     memcpy(&Pack22D[13], &tpdword, 4);		//Wielder = 0
						tpdword = ConnUser[UserParsing].EquipCount + 1;     memcpy(&Pack22D[17], &tpdword, 4);		//unknown2...
						tph2.m_wUnknown1 = 4;
						Send802(&tph2, Pack22D, sizeof(Pack22D), UserParsing);

						//229
						BYTE Pack229[0x11]; ZeroMemory(Pack229, 0x11);
						tpdword = 0x229; memcpy(&Pack229[0], &tpdword, 4);		//22D = set wielder/container
						tpbyte = ConnUser[UserParsing].EquipCount;	memcpy(&Pack229[4], &tpbyte, 1);	//EquipCount
						//byte here...
										 memcpy(&Pack229[5], &GUIDMove, 4);		//Item
						tpdword = 0xA;   memcpy(&Pack229[9], &tpdword, 4);		//Unknown, always A...
						tpdword = 0;     memcpy(&Pack229[13], &tpdword, 4);		//Coverage = 0
						tph2.m_wUnknown1 = 4;
						Send802(&tph2, Pack22D, sizeof(Pack22D), UserParsing);

						//Second 22D
						ZeroMemory(Pack22D, 0x15);
						tpdword = 0x22D; memcpy(&Pack22D[0], &tpdword, 4);		//22D = set wielder/container
						tpbyte = ConnUser[UserParsing].EquipCount;	memcpy(&Pack22D[4], &tpbyte, 1);	//EquipCount
						//byte here...
										 memcpy(&Pack22D[5], &GUIDMove, 4);		//Item
						tpdword = 2;     memcpy(&Pack22D[9], &tpdword, 4);		//Set Container
										 memcpy(&Pack22D[13], &tPackPtr[16], 4);		//Container = Bag
						tpdword = 0x34500;     memcpy(&Pack22D[17], &tpdword, 4);		//unknown2...
						tph2.m_wUnknown1 = 4;
						Send802(&tph2, Pack22D, sizeof(Pack22D), UserParsing);
						
						//EQ++
						ConnUser[UserParsing].EquipCount ++;
					} else {
						DWORD MoveItemArr[] = {
							0x0000F7B0,
							ConnUser[UserParsing].Char->GUID,
							ConnUser[UserParsing].EventCount,
							0x00000022,
							0,
							0,
							0
						};
						memcpy(&MoveItemArr[4],&tPackPtr[12],3*4);
						tph2.m_wUnknown1 = 4;
						tph2.m_dwSequence = ConnUser[UserParsing].msgID;
						ConnUser[UserParsing].EventCount++;
						Send802(&tph2, (BYTE *) &MoveItemArr[0], sizeof(MoveItemArr), UserParsing);

						BYTE Pack22D[0x15]; ZeroMemory(Pack22D, 0x15);
						DWORD tpdword;	BYTE tpbyte;
						tpdword = 0x22D; memcpy(&Pack22D[0], &tpdword, 4);		//22D = set wielder/container
						tpbyte = ConnUser[UserParsing].MoveItemCount;	memcpy(&Pack22D[4], &tpbyte, 1);	//MoveItemCount
						//byte here...
										 memcpy(&Pack22D[5], &GUIDMove, 4);		//Item
						tpdword = 2;     memcpy(&Pack22D[9], &tpdword, 4);		//2 = Set Container
										 memcpy(&Pack22D[13], &tPackPtr[16], 4);	//Container (pack)
						tpdword = 0x34500;     memcpy(&Pack22D[17], &tpdword, 4);		//unknown2
						tph2.m_wUnknown1 = 4;
						Send802(&tph2, Pack22D, sizeof(Pack22D), UserParsing);
						ConnUser[UserParsing].MoveItemCount += 2;
					}

//								DWORD abc[3];	memcpy(abc, &tPackPtr[12],4*3);
//								sprintf(sayit, "Move Item - Item: %08X, Into: %08X, Index: %08X",abc[0], abc[1], abc[2]); LogDisp(sayit);
				} else if (MType2 == 0x1A) {
					//Item Worn
					//4th dword = GUID of item
					//5th dword = coverage

					//We'll just go with equipped items now, m'kay? m'kay.

					DWORD GUIDEquip, Coverage;
					memcpy(&GUIDEquip, &tPackPtr[12],4);
					memcpy(&Coverage, &tPackPtr[16],4);		//Ignore coverage for now m'kay? m'kay.

					//F7B0/23
					DWORD F7B023[] = {
						0x0000F7B0,
						ConnUser[UserParsing].Char->GUID,
						ConnUser[UserParsing].EventCount,
						0x00000023,
						GUIDEquip,
						Coverage
					};
					tph2.m_wUnknown1 = 4;
					tph2.m_dwSequence = ConnUser[UserParsing].msgID;
					ConnUser[UserParsing].EventCount++;
					Send802(&tph2, (BYTE *) &F7B023[0], sizeof(F7B023), UserParsing);
					
					//First 22D
					BYTE Pack22D[0x15]; ZeroMemory(Pack22D, 0x15);
					DWORD tpdword;	BYTE tpbyte;
					tpdword = 0x22D; memcpy(&Pack22D[0], &tpdword, 4);		//22D = set wielder/container
					tpbyte = ConnUser[UserParsing].EquipCount;	memcpy(&Pack22D[4], &tpbyte, 1);	//EquipCount
					//byte here...
									 memcpy(&Pack22D[5], &GUIDEquip, 4);		//Item
					tpdword = 3;     memcpy(&Pack22D[9], &tpdword, 4);		//Set Wielder
									 memcpy(&Pack22D[13], &ConnUser[UserParsing].Char->GUID, 4);		//Wielder = Player
					tpdword = ConnUser[UserParsing].EquipCount + 1;     memcpy(&Pack22D[17], &tpdword, 4);		//EquipCount + 1
					tph2.m_wUnknown1 = 4;
					Send802(&tph2, Pack22D, sizeof(Pack22D), UserParsing);
					
					//Second 22D
					ZeroMemory(Pack22D, 0x15);
					tpdword = 0x22D; memcpy(&Pack22D[0], &tpdword, 4);		//22D = set wielder/container
					tpbyte = ConnUser[UserParsing].EquipCount;	memcpy(&Pack22D[4], &tpbyte, 1);	//EquipCount
					//byte here...
									 memcpy(&Pack22D[5], &GUIDEquip, 4);		//Item
					tpdword = 2;     memcpy(&Pack22D[9], &tpdword, 4);		//Set Container
					tpdword = 0;     memcpy(&Pack22D[13], &tpdword, 4);		//Container = 0
					tpdword = ConnUser[UserParsing].EquipCount + 1;     memcpy(&Pack22D[17], &tpdword, 4);		//EquipCount + 1
					tph2.m_wUnknown1 = 4;
					Send802(&tph2, Pack22D, sizeof(Pack22D), UserParsing);

					//229
					BYTE Pack229[0x11]; ZeroMemory(Pack229, 0x11);
					tpdword = 0x229; memcpy(&Pack229[0], &tpdword, 4);		//22D = set wielder/container
					tpbyte = ConnUser[UserParsing].EquipCount;	memcpy(&Pack229[4], &tpbyte, 1);	//EquipCount
					//byte here...
									 memcpy(&Pack229[5], &GUIDEquip, 4);		//Item
					tpdword = 0xA;   memcpy(&Pack229[9], &tpdword, 4);		//Unknown, always A...
									 memcpy(&Pack229[13], &Coverage, 4);		//Coverage = 0
					tph2.m_wUnknown1 = 4;
					Send802(&tph2, Pack22D, sizeof(Pack22D), UserParsing);
					
					//F749
					DWORD F749[] = {
						ConnUser[UserParsing].Char->GUID,	//Wielder
						GUIDEquip,						//Item
						1,								//Unk1
						1,								//Unk2
						//40254,							//Unk3
						0x00254 | (0x40000 + 0x30000*((ConnUser[UserParsing].EquipCount - 1) / 2)),	//Unk3, try this...
						0x80000000						//Unk4
					};
					tph2.m_wUnknown1 = 4;
					Send802(&tph2, (BYTE *) &F749[0], sizeof(F749), UserParsing);

					//EQ++
					ConnUser[UserParsing].EquipCount ++;

					ConnUser[UserParsing].Char->Equipped[EQUIPPED_WEAPON] = GUIDEquip;

				} else if (MType2 == 0x1B) {
					//Item Dropped on Ground
					//4th dword = GUID dropped
					
					//?
				} else if (MType2 == 0x1BF) {
					//Item Selected
					//4th dword = GUID selected
					
					memcpy(&ConnUser[UserParsing].SelectedItem, &tPackPtr[12],4);
				} else if (MType2 == 0x01B7) {
					//Beginning of Jump
				} else if (MType2 == 0xF61B) {
					//Player Jumped
				} else if (MType2 == 0xCA) {
					//Dunno...
				} else if (MType2 == 0x01A1) {
					//Dunno...
				} else {
					char *tps2;
					sprintf(sayit, "* 802 Pack: Seq:%08X Srv:%08X CRC:%08X Size:%04X Tm:%02X Table:%02X", tphdr->m_dwSequence, tphdr->m_dwServerID, tphdr->m_dwCRC, tphdr->m_wTotalSize, tphdr->m_bTime, tphdr->m_bTable); LogDisp(sayit);
					
					char * tps3 = new char[1 + (amountRead - (sizeof(cMessageHeader)+sizeof(cClientPacketHeader)))*5];
					ZeroMemory(tps3,1 + (amountRead - (sizeof(cMessageHeader)+sizeof(cClientPacketHeader)))*5);
					tps2 = tps3;
					for (unsigned int tpl=0; tpl < (amountRead - (sizeof(cMessageHeader)+sizeof(cClientPacketHeader))); tpl++)
					{
						sprintf(tps2, "0x%02X ", tPackPtr[tpl]);
						tps2+=5;
					}
					sprintf(sayit, "\\>Seq:%08X OID:%08X FragCnt:%04X FragLen:%04X FragIdx:%04X Unknown:%04X", tpmhdr.m_dwSequence, tpmhdr.m_dwObjectID, tpmhdr.m_wFragmentCount, tpmhdr.m_wFragmentLength, tpmhdr.m_wFragmentIndex, tpmhdr.m_wUnknown1); LogDisp(sayit);
					sprintf(sayit, "\\>Data: %s", tps3); LogDisp(sayit);
					delete [] tps3;
				}
			} else {
				char *tps2;
				sprintf(sayit, "* 802 Pack: Seq:%08X Srv:%08X CRC:%08X Size:%04X Tm:%02X Table:%02X", tphdr->m_dwSequence, tphdr->m_dwServerID, tphdr->m_dwCRC, tphdr->m_wTotalSize, tphdr->m_bTime, tphdr->m_bTable); LogDisp(sayit);
				
				char * tps3 = new char[1 + (amountRead - (sizeof(cMessageHeader)+sizeof(cClientPacketHeader)))*5];
				ZeroMemory(tps3,1 + (amountRead - (sizeof(cMessageHeader)+sizeof(cClientPacketHeader)))*5);
				tps2 = tps3;
				for (unsigned int tpl=0; tpl < (tpmhdr.m_wFragmentLength - sizeof(cMessageHeader)); tpl++)
				{
					sprintf(tps2, "0x%02X ", tPackPtr[tpl]);
					tps2+=5;
				}
				sprintf(sayit, "\\>Seq:%08X OID:%08X FragCnt:%04X FragLen:%04X FragIdx:%04X Unknown:%04X", tpmhdr.m_dwSequence, tpmhdr.m_dwObjectID, tpmhdr.m_wFragmentCount, tpmhdr.m_wFragmentLength, tpmhdr.m_wFragmentIndex, tpmhdr.m_wUnknown1); LogDisp(sayit);
				sprintf(sayit, "\\>Data: %s", tps3); LogDisp(sayit);
				delete [] tps3;
			}
			tPackPtr += tpmhdr.m_wFragmentLength - sizeof(cMessageHeader);
		}
	} else if (tphdr->m_dwFlags == 0x00001002) {
		//bTime Updated Client-Side, Ignore...
	} else {
		sprintf(sayit, "In:Seq:%08X Flg:%08X Srv:%08X CRC:%08X Size:%04X Tm:%02X Table:%02X", tphdr->m_dwSequence, tphdr->m_dwFlags, tphdr->m_dwServerID, tphdr->m_dwCRC, tphdr->m_wTotalSize, tphdr->m_bTime, tphdr->m_bTable); LogDisp(sayit);
		if ((int) (amountRead-sizeof(cClientPacketHeader)) > 0)
		{
			char * tps = new char[1 + (amountRead-sizeof(cClientPacketHeader))*5], *tps2 = tps;
			for (unsigned int tpl=0; tpl < (amountRead-sizeof(cClientPacketHeader)) ;tpl++)
			{
				sprintf(tps2, "0x%02X ", TestBuf[tpl+sizeof(cClientPacketHeader)]);
				tps2+=5;
			}
			sprintf(sayit, "* Data: %s",tps); LogDisp(sayit);
			delete [] tps;
		}
	}
}

void cACServer::RemoveItem(DWORD GUID)
{
	DWORD F747[] = {
		0x0000F747,
		GUID
	};
	cMessageHeader tph2;
	tph2.m_wUnknown1 = 3;
	for (int i=0;i<MaxUsers;i++)
	{
		if ((ConnUser[i].Connected) && (ConnUser[i].State == 6))
			Send802(&tph2, (BYTE *) F747, sizeof(F747), i);
	}
}

void cACServer::EvalObject(int User, DWORD GUID)
{
	cWorldObject *cwoItem = ObjectList[GUID];

	BYTE OutPack[0x500];
	BYTE *PackPointer = OutPack;
	DWORD tpd;//	WORD tpw;
	
	//F7b0 header
	tpd = 0xF7B0;		memcpy(PackPointer, &tpd, 4);	PackPointer += 4;
						memcpy(PackPointer, &ConnUser[User].Char->GUID, 4);	PackPointer += 4;
						memcpy(PackPointer, &ConnUser[User].EventCount, 4);	PackPointer += 4;
	tpd = 0x00C9;		memcpy(PackPointer, &tpd, 4);	PackPointer += 4;		//C9 = Identify Object
	ConnUser[User].EventCount++;

	//Figure out Flags...	
	switch (cwoItem->Type)
	{
	case OBJECT_CHARACTER:
		tpd = 0x0001;		memcpy(PackPointer, &tpd, 4);	PackPointer += 4;		//Flags - Char/Monster
		break;
	case OBJECT_PORTAL:
		tpd = 0x00010000;	memcpy(PackPointer, &tpd, 4);	PackPointer += 4;		//Flags - Portal
		break;
	}

	tpd = 0x0001;		memcpy(PackPointer, &tpd, 4);	PackPointer += 4;		//Successful Assess

	//Build Packet
	if (cwoItem->Type == OBJECT_CHARACTER)
	{
		
	}
	else if (cwoItem->Type == OBJECT_PORTAL)
	{
		cWorldObject_Portal *tpp = (cWorldObject_Portal *) cwoItem;
		DWORD Lower, Upper;
		Lower = (tpp->Flags & 0x00FF0000) >> 16;
		if (!Lower) Lower = 0xFFFFFFFF;
		Upper = (tpp->Flags & 0xFF000000) >> 24;
		if (!Upper) Upper = 0xFFFFFFFF;

		memcpy(PackPointer, &Lower, 4);	PackPointer += 4;		//Lower Limit
		memcpy(PackPointer, &Upper, 4);	PackPointer += 4;		//Upper Limit

		int packlen;
		GenString(tpp->Name, &packlen, PackPointer);  PackPointer += packlen;
	}
	
	cMessageHeader tph2;
	tph2.m_wUnknown1 = 3;	
	Send802(&tph2, OutPack, (DWORD) PackPointer - (DWORD) OutPack, User);
}