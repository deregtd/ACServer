#ifndef NETWORK_H
#define NETWORK_H

#define PI 3.1415926535

const DWORD LevelArray[] = { 0, 0, 1000, 2777, 5697, 10248, 17031, 26784, 40391, 58895, 83511, 115645, 156898, 209088, 274259, 354692,452925, 571762, 714286, 883872, 1084206, 1319289, 1593459, 1911400, 2278153, 2699136, 3180153, 3727407, 4347513, 5047517, 5834900, 6717600, 7704021, 8803044, 10024047, 11376914, 12872048, 14520384, 16333408, 18323161, 20502261, 22883912, 25481915, 28310688, 31385275, 34721359, 38335275, 42244029, 46465302, 51017472, 55919623, 61191556, 66853809, 72927666, 79435170, 86399136, 93843170, 101791673, 110269863, 119303784, 128920317, 139147200, 150013037, 161547311, 173780397, 186743581, 200469064, 214989984, 230340425, 246555428, 263671011, 281724178, 300752932, 320796288, 341894292, 364088025, 387419625, 411932296, 437670319, 464679072, 493005039, 522695823, 553800159, 586367933, 620450186, 656099136, 693368187, 732311940, 772986213, 815448050, 859755734, 905968800, 954148054, 1004355577, 1056654747, 1111110248, 1167788081, 1226755584, 1288081441, 1351835695, 1418089761, 1486916445, 1558389948, 1632585888, 1709581309, 1789454692, 1872285975, 1958156562, 2047149336, 2139348672, 2234840456, 2333712089, 2436052509, 2541952200, 2651503203, 2764799136, 2881935203, 3003008207, 3128116563, 3257360317, 3390841150, 3528662400, 3670929071, 3817747844, 3969227097, 4125476914, 4286609098 };
const DWORD SkillArray[] = { 110,277,501,784,1125,1527,1988,2511,3097,3746,4459,5238,6084,6998,7982,9038,10167,11372,12654,14015,15459,16988,18604,20311,22113,24012,26014,28122,30341,32676,35132,37716,40434,43293,46301,49465,52795,56300,59991,63878,67975,72295,76851,81659,86737,92102,97775,103775,110128,116858,123991,131559,139591,148124,157194,166843,177113,188053,199715,212153,225429,239609,254762,270967,288306,306870,326756,348070,370928,395453,421779,450054,480434,513091,548210,585992,626654,670432,717582,768378,823122,882136,945773,1014414,1088469,1168386,1254649,1347781,1448351,1556972,1674311,1801089,1938088,2086155,2246205,2419233,2606314,2808613,3027394,3264023,3519983,3796877,4096444,4420567,4771285,5150808,5561528,6006039,6487148,7007896,7571580,8181768,8842327,9557443,10331656,11169877,12077431,13060084,14124082,15276190,16523738,17874666,19337572,20921773,22637359,24495261,26507320,28686361,31046278,33602120,36370190,39368147,42615120,46131828,49940719,54066105,58534323,63373901,68615745,74293328,80442912,87103777,94318471,102133083,110597540,119765922,129696811,140453665,152105222,164725942,178396483,193204214,209243776,226617688,245437001,265822007,287903011,311821164,337729361,365793227,396192167,429120520,464788799,503425038,545276249,590610001,639716134,692908610,750527522,812941268,880548904,953782704,1033110914,1119040753,1212121655,1312948783,1422166831,1540474151,1668627219,1807445467,1957816530,2120701915,2297143157,2488268472,2695299977,2919561502,3162487055,3425629996,3710672964,4019438644 };
const int CreditLevel[] = { 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 14, 16, 18, 20, 23, 26, 29, 32, 35, 40, 45, 50, 55, 60, 65, 70, 70, 80, 85, 90, 95, 100, 105, 110, 115, 120, 125, 666 };

#define COLOR_GREEN			1
#define COLOR_WHITE			2
#define COLOR_YELLOW		3
#define COLOR_LIGHTBROWN	4
#define COLOR_MAGENTA		5
#define COLOR_RED			6
#define COLOR_GREEN2		7
#define COLOR_PINK			8
#define COLOR_LIGHTPINK		9
#define COLOR_YELLOW2		10
#define COLOR_LIGHTBROWN2	11
#define COLOR_GREY			12
#define COLOR_CYAN			13
#define COLOR_AQUAMARINE	14
#define COLOR_RED2			15
#define COLOR_GREEN3		16
#define COLOR_BLUE			17
#define COLOR_GREEN4		18

#define GLOBAL_MESSAGE		-87654

#define EQUIPPED_HEAD			0
#define EQUIPPED_CHEST_U		1
#define EQUIPPED_GIRTH_U		2
#define EQUIPPED_UARMS_U		3
#define EQUIPPED_LARMS_U		4
#define EQUIPPED_HANDS			5
#define EQUIPPED_ULEGS_U		6
#define EQUIPPED_LLEGS_U		7
#define EQUIPPED_FEET			8
#define EQUIPPED_CHEST			9
#define EQUIPPED_GIRTH			10
#define EQUIPPED_UARMS			11
#define EQUIPPED_LARMS			12
#define EQUIPPED_ULEGS			13
#define EQUIPPED_LLEGS			14
#define EQUIPPED_NECKLACE		15
#define EQUIPPED_RBRACELET		16
#define EQUIPPED_LBRACELET		17
#define EQUIPPED_RRING			18
#define EQUIPPED_LRING			19
#define EQUIPPED_WEAPON			20
#define EQUIPPED_SHIELD			21
#define EQUIPPED_PROJECTILE		22
#define EQUIPPED_AMMO			23
#define EQUIPPED_FOCUS			24

#define SKILL_AXE				0x01
#define SKILL_BOW				0x02
#define SKILL_XBOW				0x03
#define SKILL_DAGGER			0x04
#define SKILL_MACE				0x05
#define SKILL_MELEE				0x06
#define SKILL_MISSILE			0x07
#define SKILL_SPEAR				0x09
#define SKILL_STAFF				0x0A
#define SKILL_SWORD				0x0B
#define SKILL_THROWN			0x0C
#define SKILL_UNARMED			0x0D
#define SKILL_LORE				0x0E
#define SKILL_MAGICD			0x0F
#define SKILL_MANAC				0x10
#define SKILL_APPRAISEITEM		0x12
#define SKILL_ASSESSPERSON		0x13
#define SKILL_DECEPTION			0x14
#define SKILL_HEALING			0x15
#define SKILL_JUMP				0x16
#define SKILL_LOCKPICK			0x17
#define SKILL_RUN				0x18
#define SKILL_ASSESSCREATURE	0x1B
#define SKILL_APPRAISEWEAPON	0x1C
#define SKILL_APPRAISEARMOR		0x1D
#define SKILL_APPRAISEMAGICITEM	0x1E
#define SKILL_CREATURE			0x1F
#define SKILL_ITEM				0x20
#define SKILL_LIFE				0x21
#define SKILL_WAR				0x22
#define SKILL_LEADERSHIP		0x23
#define SKILL_LOYALTY			0x24
#define SKILL_FLETCHING			0x25
#define SKILL_ALCHEMY			0x26
#define SKILL_COOKING			0x27
#define SKILL_UNASSIGNED		0x80

struct cClientPacketHeader
{
	DWORD	m_dwSequence;
	DWORD	m_dwFlags;
	DWORD	m_dwServerID;
	DWORD	m_dwCRC;
	WORD	m_wTotalSize;
	BYTE	m_bTime, m_bTable;
	DWORD	m_dwSpecial;
};

struct cServerPacketHeader
{
	DWORD	m_dwSequence;
	DWORD	m_dwFlags;
	DWORD	m_dwServerID;
	DWORD	m_dwCRC;
	WORD	m_wTotalSize;
	BYTE	m_bTime, m_bTable;
};

struct cMessageHeader
{
	DWORD m_dwSequence;
	DWORD m_dwObjectID;
	WORD m_wFragmentCount;
	WORD m_wFragmentLength;
	WORD m_wFragmentIndex, m_wUnknown1;
};


struct stConnUser {
	bool Connected;
	int State;

	sockaddr_in sockaddy;
	DWORD charGUID;
	char ZoneName[20];

	BYTE bTime;
	DWORD RecTime, LastTime;

	cWorldObject_Char Chars[5];

	bool Connable; int ConnTimer;
	int ZoneNum;

	DWORD curSeq; 
	DWORD AttackCount;
	WORD move_count, PortalCount, AnimCount, EventCount, OverrideCount;
	BYTE MoveItemCount, EquipCount, Count237[0x20], Count244[3];
	DWORD msgID;
	DWORD lastInSeq;

	char Status[64];

	DWORD SelectedItem;
	float PointX, PointY;

	cWorldObject_Char * Char;

	cWorldObject * MainPackPtr[102], * SidePacksPtr[7], * EquippedPtr[25];

	std::map<DWORD, cWorldObject *> ObjectCache;
};

struct cAnimStruct
{
	DWORD dwf74c;
	DWORD dwGUID;
	WORD wNumLogins;
	WORD wNumInteractions;
	WORD wNumAnimations;
	WORD wFlag;
	WORD wUnk1;
	WORD wAnimation_Family;
	union {
		struct {
			WORD wUnk2;
			WORD wUnk3;
		};
		DWORD GUIDTarget;
	};
	union {
		struct {
			WORD wAnimation_to_Play;
			WORD wAnimation_Seqnum;
		};
		DWORD dwUnk1;
	};
	union {
		float fPlaySpeed;
		DWORD dwUnk2;
	};
};

struct cAnimStructEx : public cAnimStruct
{
	float fUnk1;
	DWORD Zero;
};

struct stIPStore {
	char Login[20];
	char Pass[20];
	in_addr      IP;
	bool Enabled;
	bool Valid;
	int ZoneNum;
};

struct stAccounts {
	char Login[20];
	char Pass[20];
	DWORD Chars[5];
	WORD Secs2Del[5];
	char Names[5][32];
	WORD LoggedIn;
};

class cACServer {
public:
        cACServer();
        ~cACServer();
	
	void SaveAccounts();
	void LoadAccounts();

	void IncTimes();
	void DisconnectUser(int User);

	void StartListen();
	void CheckMessages();
	
	DWORD GetMagicNumber(BYTE * buf, UINT cb, BOOL bIncludeSize);

	HWND MainWnd;

	int MaxUsers, NumConnected;
	char ServerName[64];

	stConnUser ConnUser[128];

	int ListenPort;
	char LocalIP[16];

	stIPStore IPStore[16384]; int NumStored;
	stAccounts ZonePasses[16384]; int NumPasses;

	void ServerMessage(int User, char *Text, DWORD Color);

	void ReorgCharFile();

	void GiveXP(int User, int Type, DWORD Amount);

	void WorldServerParse(int UserParsing, BYTE *tPackPtr, int amountRead, cClientPacketHeader *tphdr);
	
private:
	void LogDisp(char *toDisp);
	void PingReply(int User);
	void UpdateCharInfo(int User, char * NewText);

	void SendCharList(int User);
	void CalcNextFreeGUID();

	void Send802(cMessageHeader *msghead, BYTE *data, int datalen, int User);

	void SaveCharacter(int UserNum);

	int Generate_F7B0_13(BYTE * OutPack, int User);

	void LoadObjects();
	void SaveObjects();

	void SendLandblock(int User, WORD Landblock);
	void MoveUser(int User, Location_t *loc, bool Portal, bool Override);
	void SendAnim(int User, WORD AnimNum);
	void SendParticle(int User, DWORD ParticleNum);
	void PointAt(int User, DWORD GuidAt);
	void ActionComplete(int User);
	void RemoveItem(DWORD GUID);
	void EvalObject(int User, DWORD GUID);

	SOCKET charSocket;

	char MOTDa[2048],MOTDb[2048];

	bool NeedToDelete;

	DWORD NextFreeCharGUID;

	unsigned char TestBuf[4096];

	char sayit[10240];

	std::map<DWORD, cWorldObject *> ObjectList;
	std::map<DWORD, cWorldObject *> LBObjects[0x10000];
	std::map<DWORD, cWorldObject *> Portals[0x10000];
};

float GetDistance(Location_t *loc1, Location_t *loc2);
void MakePacket16();

#endif
