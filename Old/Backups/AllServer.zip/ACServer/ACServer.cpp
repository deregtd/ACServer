// ACServer.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "ACServer.h"

cACServer *theServer;

// Global Variables:
HINSTANCE hInst;								// current instance

bool QuitNow = false;

NOTIFYICONDATA tnid; 
SOCKADDR_IN DirServer;
LPHOSTENT lpHostEntry;

DWORD DirTimerID;

char ServerNameCorr[300] = { 0 };

bool RecentAction = false;

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
 	// TODO: Place code here.
	MSG msg;
	HACCEL hAccelTable;

	HWND hWnd;

	hInst = hInstance; // Store instance handle in our global variable

	WSADATA wsaData;
	WORD wVersionRequested = 0x0202;
	int err;

	err = WSAStartup(wVersionRequested, &wsaData); //for winsock startup

	TCHAR szTetrisWindowClass[] = "MyInvisCharWndClass";

	WNDCLASS myc; ZeroMemory(&myc, sizeof(myc));
	myc.lpszClassName = szTetrisWindowClass;
	myc.hInstance = hInst;
	myc.lpfnWndProc = InvisWndProc;
	int a = RegisterClass(&myc);
	HWND backwindow = CreateWindow(szTetrisWindowClass, _T(""), WS_POPUP, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, 0, 0, hInst, NULL);

	hWnd = CreateDialog(hInstance,(LPCTSTR) IDD_MAINDLG, backwindow, &WndProc);

	//Shell Icon Start
        char lpszTip[30] = "ACServer!";
	BOOL res; 

	int maintimer = SetTimer(hWnd, 758, 250, NULL);

	tnid.cbSize = sizeof(NOTIFYICONDATA); 
	tnid.hWnd = hWnd; 
	tnid.uID = 4097; //uID; 
	tnid.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP; 
	tnid.uCallbackMessage = WM_USER + 2; 
    HICON hicon = (HICON) LoadImage(hInst, (LPCSTR) IDI_NOACT, IMAGE_ICON, 0, 0, LR_DEFAULTSIZE);
	tnid.hIcon = hicon; 
	if (lpszTip) 
		lstrcpyn(tnid.szTip, lpszTip, sizeof(tnid.szTip)); 
	else 
		tnid.szTip[0] = '\0'; 

	res = Shell_NotifyIcon(NIM_ADD, &tnid); 

	if (hicon) 
		DestroyIcon(hicon);
	//Shell Icon End


	srand((unsigned) time(NULL));

	char myhost[51]; myhost[50] = 0;
	gethostname(myhost, 50);
	HOSTENT *tphost = gethostbyname(myhost);

	char tpip[64]; BYTE ip[4];
	memcpy(ip, tphost->h_addr_list[0],4);
	sprintf(tpip, "%i.%i.%i.%i:%i",ip[0],ip[1],ip[2],ip[3],9002);
	SetDlgItemText(hWnd, IDC_CSIP, tpip);
	sprintf(tpip, "%i.%i.%i.%i:%i",ip[0],ip[1],ip[2],ip[3],9004);
	SetDlgItemText(hWnd, IDC_WSIP, tpip);
	sprintf(tpip, "Unnamed Server");
	SetDlgItemText(hWnd, IDC_SERVNAME, tpip);

	theServer = new cACServer;
	theServer->MainWnd = hWnd;

	if (!hWnd)
		return FALSE;
	
	hAccelTable = LoadAccelerators(hInstance, (LPCTSTR)IDC_ACSERVER);
	
	SetTimer(hWnd, 0x00AC, 1000, IncTimer);

	while (!QuitNow) 
	{
		GetMessage(&msg, NULL, 0, 0);
		if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	KillTimer(hWnd, 0x00AC);
	KillTimer(hWnd, 758);

	return msg.wParam;
}

VOID CALLBACK IncTimer( HWND hwnd, UINT uMsg, UINT idEvent, DWORD dwTime )
{
	theServer->IncTimes();
}
 
DWORD WINAPI DirTimer( LPVOID lpParam )
{
	while (!QuitNow)
	{
		//Update Directory Server
		SOCKET DirSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

		connect(DirSocket, (LPSOCKADDR) &DirServer, sizeof(sockaddr));

		char constring[150];
		sprintf(constring, "GET /scripts/DirServ5.exe?Name=%s&Port=%i&Type=1&Users=%i\n", ServerNameCorr, theServer->ListenPort, theServer->NumConnected);
		send(DirSocket, constring, strlen(constring), NULL);

		Sleep(15000);
	}
	return(0);
}

int CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	int wmId, wmEvent;
	int i;

	switch (message) 
	{
	case WM_COMMAND:
		wmId    = LOWORD(wParam); 
		wmEvent = HIWORD(wParam); 
		// Parse the menu selections:
		switch (wmId)
		{
			case IDM_EXIT:
			   DestroyWindow(hWnd);
			   break;
			case ID_FILE_RESETLOG:
				SendDlgItemMessage(hWnd, IDC_LIST1, LB_RESETCONTENT, 0, 0);
				break;
			case ID_FILE_RESETALLCONNECTIONS:
				for (i=0;i<128;i++)
					theServer->DisconnectUser(i);
				break;
			case IDC_STARTLISTEN:
				{
					char tptxt[64], tptxt2[5], *tpptr;
					GetDlgItemText(hWnd, IDC_CSIP, tptxt, 30);
					tpptr = strstr(tptxt, ":") + 1;
					memcpy(tptxt2, tpptr, strlen(tpptr));
					tpptr--;
					tpptr[0] = 0;
					ZeroMemory(theServer->LocalIP, sizeof(theServer->LocalIP));
					memcpy(theServer->LocalIP, tptxt, strlen(tptxt));
					sscanf(tptxt2, "%i", &theServer->ListenPort);						

					GetDlgItemText(hWnd, IDC_SERVNAME, tptxt, 64);
					strcpy(theServer->ServerName, tptxt);

					theServer->LoadAccounts();
					theServer->StartListen();

					lpHostEntry = gethostbyname("localhost");
					
					ZeroMemory(&DirServer, sizeof(DirServer));
					DirServer.sin_family = AF_INET;
					DirServer.sin_port = htons(80);
					DirServer.sin_addr = *((LPIN_ADDR)*lpHostEntry->h_addr_list); 

					{
						char *tpp = ServerNameCorr;
						for (int i=0;i<strlen(theServer->ServerName);i++)
						{
							if (theServer->ServerName[i] != ' ')
							{
								*tpp = theServer->ServerName[i];
								tpp++;
							} else {
								strcat(tpp, "%20");
								tpp+=3;
							}
						}
						*tpp = 0;
					}

//					SetTimer(hWnd, 0x00AE, 15000, DirTimer);
//					DirTimer(0,0,0,0);
					CreateThread(NULL, NULL, DirTimer, NULL, NULL, &DirTimerID);
				}
				break;
			case ID_FILE_KICKSELECTEDUSER:
				i = SendDlgItemMessage(hWnd, IDC_CHARLIST, LB_GETCURSEL, 0, 0);
				if ((i != LB_ERR) && (i > 0))
					theServer->DisconnectUser(i-1);
				break;
			default:
			   return DefWindowProc(hWnd, message, wParam, lParam);
		}
		break;
	
	case WM_CLOSE:
		DestroyWindow(hWnd);
		break;

	case WM_DESTROY:
		delete theServer;
		QuitNow = true;
		Shell_NotifyIcon(NIM_DELETE, &tnid); 
		PostQuitMessage(0);
		break;

	case WM_TIMER:
		{
			HICON hicon;
			if (RecentAction)
				hicon = (HICON) LoadImage(hInst, (LPCSTR) IDI_ACT, IMAGE_ICON, 0, 0, LR_DEFAULTSIZE);
			else
				hicon = (HICON) LoadImage(hInst, (LPCSTR) IDI_NOACT, IMAGE_ICON, 0, 0, LR_DEFAULTSIZE);
			tnid.hIcon = hicon; 
			sprintf(tnid.szTip, "%s - %i/128", theServer->ServerName, theServer->NumConnected);

			Shell_NotifyIcon(NIM_MODIFY, &tnid); 

			if (hicon) 
				DestroyIcon(hicon);

			RecentAction = false;
		}
		break;

	case WM_USER+1:
		RecentAction = true;
		theServer->CheckMessages();
		RecentAction = true;
		break;
	case WM_USER+2:
		switch (lParam)
		{
		case 512:
			//Mouseover
			break;
		case 513:
			//LButtondown
			{
				WINDOWPLACEMENT WP; ZeroMemory(&WP, sizeof(WP));
				WP.length = sizeof(WP);
				GetWindowPlacement(hWnd, &WP);
				WP.showCmd = SW_MINIMIZE;
				SetWindowPlacement(hWnd, &WP);
				WP.showCmd = SW_SHOWNORMAL;
				SetWindowPlacement(hWnd, &WP);
			}
			break;
		case 516:
			//RButtondown
			{
				WINDOWPLACEMENT WP; ZeroMemory(&WP, sizeof(WP));
				WP.length = sizeof(WP);
				GetWindowPlacement(hWnd, &WP);
				WP.showCmd = SW_MINIMIZE;
				SetWindowPlacement(hWnd, &WP);
				ShowWindow(hWnd, SW_HIDE);
			}
			break;
		}
		break;
	case WM_SIZE:
		if (wParam == SIZE_MINIMIZED)
			SendMessage(hWnd, WM_USER+2, 0, 516);
		break;
   }
   return false;
}

long CALLBACK InvisWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	return(DefWindowProc(hWnd, message, wParam, lParam));
}
