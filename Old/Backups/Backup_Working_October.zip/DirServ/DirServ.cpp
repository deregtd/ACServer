// DirServ.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

struct stServerInfo {
	char Name[40];
	char IP[16];
	unsigned short Port;
	time_t LastUpdate;
	int Users;
	int Type;
};

int main()
{
	char buff[10000]; memset(buff, 0, 10000);
	long contentlength = 0;
	
	printf("Content-type: text/html\n\n");

	char *omg = getenv("QUERY_STRING");
	if (omg)
	{
		contentlength = strlen(omg);
		strcpy(buff, omg);
	}
	
//	printf("Length: %i<BR>",contentlength);
//	printf("Data: %s<HR>", buff);
	
	char Keys[24][200], *posat = buff; int NumKeys = 0;
	memset(Keys, 0, sizeof(Keys));

	if (contentlength)
	{
		while (strchr(posat, '&'))
		{
			memcpy(Keys[NumKeys], posat, strchr(posat, '&') - buff);
			NumKeys++;

			posat = strchr(posat, '&') + 1;
		}
		
 		memcpy(Keys[NumKeys], posat, strlen(posat));
		NumKeys++;
	}

	int i;
	stServerInfo Server[256]; int NumServers = 0;

	time_t CurTime = time(NULL);

	FILE *in = fopen("serverlist.txt", "rb");

	fseek(in, 0, SEEK_END);
	int flen = ftell(in);
	fseek(in, 0, SEEK_SET);

	fread(Server, flen, 1, in);
	NumServers = (int) (flen / sizeof(stServerInfo));

	fclose(in);

	char KeyLeft[200], KeyRight[200];  memset(KeyLeft, 0, 200); memset(KeyRight, 0, 200);
	bool NameSet = false, PortSet = false, TypeSet = false;
	Server[NumServers].Users = 0;
	for (i=0;i<NumKeys;i++)
	{
		if (strchr(Keys[i], '='))
		{
			memcpy(KeyLeft, Keys[i], strchr(Keys[i], '=') - Keys[i]);
			memcpy(KeyRight, strchr(Keys[i], '=') + 1, strlen(strchr(Keys[i], '=') + 1));
		}

//		printf("Pair: %s = %s<BR>", KeyLeft, KeyRight);

		if (stricmp(KeyLeft, "Name") == 0) {
			strcpy(Server[NumServers].Name, KeyRight);
			while (strstr(Server[NumServers].Name, "%20"))
			{
				char *tpi = strstr(Server[NumServers].Name, "%20");
				*tpi = ' ';
				int tpl = strlen(tpi+3);
				memcpy(tpi+1, tpi+3, tpl);
				*(tpi + 1 + tpl) = 0;
			}
			NameSet = true;
		}
		if (stricmp(KeyLeft, "Port") == 0) { sscanf(KeyRight, "%i", &Server[NumServers].Port); PortSet = true; }
		if (stricmp(KeyLeft, "Type") == 0) { sscanf(KeyRight, "%i", &Server[NumServers].Type); TypeSet = true; }
		if (stricmp(KeyLeft, "Users") == 0) { sscanf(KeyRight, "%i", &Server[NumServers].Users); }
	}
	
	if (PortSet && NameSet && TypeSet)
	{
		strcpy(Server[NumServers].IP, getenv("REMOTE_ADDR"));
		Server[NumServers].LastUpdate = time(NULL);

		bool SrvF = false;
		for (i=0;i<NumServers;i++)
		{
			if ((stricmp(Server[i].IP, Server[NumServers].IP) == 0) && (Server[i].Port == Server[NumServers].Port))
			{
				memcpy(&Server[i], &Server[NumServers], sizeof(stServerInfo));
				i = NumServers;
				SrvF = true;
			}
		}
		
		if (!SrvF)
			NumServers++;
	}

	FILE *out = fopen("serverlist.txt", "wb");

	printf("<HTML><HEAD><TITLE>Test Server List</TITLE></HEAD><BODY BGCOLOR=BLACK TEXT=WHITE LINK=LIGHTBLUE>\n");

	printf("<TABLE BORDER=1 BORDERCOLOR=BLUE><TR><TH></TH><TH>Server Name</TH><TH>IP Address:Port</TH><TH>Users</TH><TH>TSU</TH></TR>\n");

	for (i=0;i<NumServers;i++)
	{
		if ((CurTime - Server[i].LastUpdate) > 60)
			Server[i].Port = 0;

		if (Server[i].Port > 0)
		{
			printf("<TR><TD>");

			if (Server[i].Type == 1)
			{
				//Akilla
				printf("<A HREF=""akilla://%s:%i/"">Connect (A)</A>", Server[i].IP, Server[i].Port);
			} else if (Server[i].Type == 2) {
				//Sentou
				printf("<A HREF=""sentou://%s:%i/"">Connect (S)</A>", Server[i].IP, Server[i].Port);
			}

			printf("</TD><TD>%s</TD><TD>%s:%i</TD><TD>%i/128</TD><TD>%i</TD></TR>\n", Server[i].Name, Server[i].IP, Server[i].Port, Server[i].Users, CurTime - Server[i].LastUpdate);

			fwrite(&Server[i], sizeof(stServerInfo), 1, out);
		}
	}

	printf("</TABLE></BODY></HTML>\n");

	fclose(out);

	return 0;
}

