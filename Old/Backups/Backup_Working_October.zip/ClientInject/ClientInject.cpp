// ClientInject.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include "ClientInject.h"

#include <atlbase.h>
#include <stdio.h>
#include <winsock2.h>

static bool bRegisteredInAC = false;
static bool bInitialized = false;
static HMODULE g_hModule = NULL;

BOOL APIENTRY DllMain( HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved )
{
   if ( ul_reason_for_call == DLL_PROCESS_ATTACH )
   {
      g_hModule = hModule;
      DisableThreadLibraryCalls ( hModule );

      // Check out the project we're in - if it's client.exe, hook stuff up
      TCHAR szFilename[ MAX_PATH ];
      ::GetModuleFileName( NULL, szFilename, MAX_PATH );

      LPTSTR strProcessName = ::_tcsrchr( szFilename, _T( '\\' ) );
      strProcessName[ 7 ] = _T( '\0' );

      if( ::_tcsicmp( strProcessName + 1, _T( "client" ) ) == 0 )
         bRegisteredInAC = true;
   }

   return TRUE;
}

// one instance for all processes
#pragma data_seg( "InjectDll" )
HHOOK g_hHook = NULL;
DWORD g_dwIP = 0;
DWORD g_sConnPort = 0;
DWORD g_szUsername = 0,
   g_szUsername1 = 0,
   g_szUsername2 = 0,
   g_szUsername3 = 0,
   g_szUsername4 = 0,
   g_szUsername5 = 0,
   g_szUsername6 = 0,
   g_szUsername7 = 0,
   g_szUsername8 = 0,
   g_szUsername9 = 0;
DWORD g_szPassword = 0,
   g_szPassword1 = 0,
   g_szPassword2 = 0,
   g_szPassword3 = 0,
   g_szPassword4 = 0,
   g_szPassword5 = 0,
   g_szPassword6 = 0,
   g_szPassword7 = 0,
   g_szPassword8 = 0,
   g_szPassword9 = 0;
#pragma data_seg()

typedef void (*AdapterInitFn)( DWORD dwIP, char *, char *, short );

// The hook function - all it does is continue calls
LRESULT CALLBACK hookCBTProc( int nCode, WPARAM wParam, LPARAM lParam )
{
   LRESULT lr = ::CallNextHookEx ( g_hHook, nCode, wParam, lParam );

   if ( !bRegisteredInAC )
      return lr;

   if ( bInitialized )
      // Prevent recursion from wiping us out
      return lr;

   bInitialized = true;

   // MessageBox ( NULL, _T( "hookCBTProc" ), _T( "ClientInject.dll" ), MB_OK );

   // Assume client adapter is in the same directly as this DLL
   TCHAR szPath[ MAX_PATH ];
   ::GetModuleFileName ( g_hModule, szPath, MAX_PATH );

   LPTSTR strModuleName = ::_tcsrchr( szPath, _T( '\\' ) );
   ::_tcscpy ( strModuleName + 1, _T( "ClientAdapter.dll" ) );

   HMODULE hMod = ::LoadLibrary ( szPath );
   if ( hMod != NULL )
   {
      AdapterInitFn fninit = reinterpret_cast< AdapterInitFn > ( ::GetProcAddress ( hMod, _T( "InitClientAdapter" ) ) );

      if ( fninit != NULL )
         fninit ( g_dwIP, reinterpret_cast< char * > ( &g_szUsername ), reinterpret_cast< char * > ( &g_szPassword ),  (short) g_sConnPort );
   }

   // Otherwise, set the event indicating startup and return
   HANDLE hEvent = ::OpenEvent ( EVENT_ALL_ACCESS, FALSE, _T( "ACEmuClientExecuted" ) );
   if ( hEvent != NULL )
   {
      ::SetEvent ( hEvent );
      ::CloseHandle ( hEvent );
   }

   return lr;
}

void executeClient ( DWORD dwIP, char *szUsername, char *szPassword, short ConnPort )
{
   // Install the global hook, injecting this DLL into every other process
   HANDLE hEvent = ::CreateEvent ( NULL, TRUE, FALSE, _T( "ACEmuClientExecuted" ) );
   g_dwIP = dwIP;
   ::strcpy ( reinterpret_cast< char * > ( &g_szUsername ), szUsername );
   ::strcpy ( reinterpret_cast< char * > ( &g_szPassword ), szPassword );
   g_sConnPort = ConnPort;
   g_hHook = ::SetWindowsHookEx ( WH_CBT, hookCBTProc, g_hModule, 0 );

   if ( g_hHook == NULL )
   {
      DWORD dwError = ::GetLastError ();
   }

   // Locate and execute the client.exe process with a fancy command line
   CRegKey rk;
   if ( rk.Open ( HKEY_LOCAL_MACHINE, _T( "Software\\Microsoft\\Microsoft Games\\Asheron's Call\\1.00" ) ) == ERROR_SUCCESS )
   {
      TCHAR szPath[ MAX_PATH ];
      DWORD dwSize = MAX_PATH;

      if ( rk.QueryValue ( szPath, _T( "InstallationDirectory" ), &dwSize ) == ERROR_SUCCESS )
      {
         // Shrink the path to remove any spaces
         ::GetShortPathName ( szPath, szPath, MAX_PATH );

         TCHAR szCommandLine[ 2048 ];
         in_addr addr;
         addr.S_un.S_addr = dwIP;

		sprintf(szPath, "c:\\ac");

        char *addrout = inet_ntoa ( addr ); 
		::_stprintf ( szCommandLine, _T( "%s\\client.exe -h %s -p %i" ), szPath, 
            addrout, ConnPort );

         STARTUPINFO si = { sizeof ( STARTUPINFO ), };
         PROCESS_INFORMATION pi;

         if ( CreateProcess ( NULL, szCommandLine, NULL, NULL, FALSE, NORMAL_PRIORITY_CLASS, NULL, szPath, &si, &pi ) )
         {
            // Wait for client startup
            ::WaitForSingleObject ( hEvent, INFINITE );

            ::CloseHandle ( pi.hThread );
            ::CloseHandle ( pi.hProcess );
         }
      }
   }

   // Cleanup
   ::UnhookWindowsHookEx( g_hHook );
   g_hHook = NULL;
}
